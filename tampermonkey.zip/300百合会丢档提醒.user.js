// ==UserScript==
// @name         300百合会丢档提醒
// @namespace    https://bbs.yamibo.com
// @version      0.1
// @description  在输入框有内容时如关闭页面进行提醒
// @author       whitewagtail
// @include      /https?://bbs.yamibo.com/*
// @icon         https://www.yamibo.com/favicon.ico
// @grant        none
// @license      MIT
// ==/UserScript==

(function() {
    'use strict';

    function prevent(event) {
        event.preventDefault();
        event.returnValue = '';
    }
    document.addEventListener('keydown', function (e) {
        if (document.getElementById('fastpostmessage').value !== '') {
            window.addEventListener('beforeunload', prevent);
        } else { window.removeEventListener('beforeunload', prevent); }
    });
})();