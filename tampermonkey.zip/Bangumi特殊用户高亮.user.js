// ==UserScript==

// @name         Bangumi特殊用户高亮

// @version      0.1

// @description  Bangumi特殊用户高亮

// @author       易坂喵之屑

// @match        https://bangumi.tv/*

// @match        https://bgm.tv/*

// @match        https://chii.in/*

// @icon         https://bgm.tv/img/favicon.ico

// @grant  none

// ==/UserScript==



$('[href*="/user/"].l').each(function () {

    var item = $(this);

    var strs = item.attr("href").split('/');

    if(strs.length==3)

    {

        $.ajax({

            type: "get",

            url: `https://api.bgm.tv/v0/users/${strs[2]}`,

            success: function (response) {

                if(response.user_group==4||response.user_group==5)

                {

                    item.css("color","#C71585")

                }else if(response.user_group!=10)

                {

                    item.css("color","#F09199")

                }

            }

        });

    }

});