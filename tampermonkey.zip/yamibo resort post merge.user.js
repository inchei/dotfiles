// ==UserScript==
// @name         yamibo resort post merge
// @namespace    w-yamibo-manga-resort
// @version      0.1.0
// @description  try to take over the world!
// @author       You
// @match        https://bbs.yamibo.com/thread-521400-1-1.html
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';
const url = "https://bbs.yamibo.com/thread-519989-1-1.html";
async function PmRequest(url){
    return new Promise(function(resolve){
        let a = new XMLHttpRequest();
        a.open("get", url, true);
        a.responseType = 'document';
        a.onload = function(){
            resolve(a.responseXML);
        }
        a.send();
    });
}
PmRequest(url)
    .then((body)=>{
        let posts = body.getElementsByClassName("plhin");
        let postlist = document.getElementById("postlist");
        for(let post of posts){
            let cpost = document.importNode(post.parentNode, true);
            postlist.append(cpost);
        }
    });

    // Your code here...
})();