// ==UserScript==
// @name         300百合会快速翻页
// @namespace    https://bbs.yamibo.com
// @version      0.5
// @description  按键盘左右键翻页
// @author       whitewagtail
// @include      /https?://bbs.yamibo.com/(thread|forum)*
// @icon         https://www.yamibo.com/favicon.ico
// @grant        none
// @license      MIT
// ==/UserScript==

(function() {
    'use strict';

    let nxt = document.getElementsByClassName('nxt')[0];
    let prev = document.getElementsByClassName('prev')[0];
    document.addEventListener('keydown', function (e) {
        let inputs = [];
        Object.values(document.getElementsByTagName('input')).map(input=>{inputs.push(input)});
        Object.values(document.getElementsByTagName('textarea')).map(input=>{inputs.push(input)});
        if (!inputs.includes(document.activeElement)) {
            let keyCode = event.keyCode;
            if (keyCode === 37 && prev) { prev.click() }
            if (keyCode === 39 && nxt) { nxt.click() }
        }
    })
})();