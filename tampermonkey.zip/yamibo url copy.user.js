// ==UserScript==
// @name         yamibo url copy
// @namespace    w-yamibo-url-copy
// @version      0.1.1
// @description  copy yamibo urls in post
// @author       You
// @match        https://bbs.yamibo.com/thread-*
// @match        https://bbs.yamibo.com/forum.php?mod=viewthread&tid=*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=yamibo.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
const newlinenum = 20;
document.addEventListener("keydown", (e)=>{
    if(e.keyCode == 65 && e.altKey){
        let frag = getSelectFrag();
        output(frag);
    }else if(e.keyCode == 83 && e.altKey){
        let frag = getSelectFrag();
        outputOriformat(frag);
    }
})
function getSelectFrag(){
    console.clear();
    let Sel = window.getSelection();
    let frag = Sel.getRangeAt(0).cloneContents();
    let links = frag.querySelectorAll("a");
    for(let link of links){
        if(link.href.match(/^https\:\/\/bbs\.yamibo\.com\/forum\.php/) !== null){
            let m = link.href.match(/&tid=(\d+)&page=1(?!#pid)/);
            if(m !== null){
                link.href = "https://bbs.yamibo.com/thread-"+m[1]+"-1-1.html"
            }
        }
        link.innerText = chtoint(link.innerText);
        if(link.innerText.length < 2){
            link.innerText = '0'+link.innerText;
        }
    }
    return frag.cloneNode(true);
}
function chtoint(chap){
    let num = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九']
    let hun = '百';
    let ten = '十';
    let newchap = '';
    if(chap[0] == ten){newchap += 1};
    for(let i = 0; i < 10; i++){
        if(chap[0] == num[i]){
            newchap += i.toString();
            break;
        }
    }
    if(newchap == ''){
        return chap;
    } else {
        for(let pos = 1; pos < chap.length; pos++){
            if(chap[pos] == hun || chap[pos] == ten){
                continue;
            } else {
                for(let i = 0; i < 10; i++){
                    if(chap[pos] == num[i]){
                        newchap += i.toString();
                        break;
                    }
                }
            }
        }
        let tail = chap[chap.length-1];
        if(tail == hun){
            newchap += '00';
        } else if (tail == ten){
            newchap += '0';
        }
    }
    return newchap;
}

function output(frag){
    let links = frag.querySelectorAll("a");
    let str = '';
    let i = 0;
    for(let link of links){
        str = str+'[url=' + link.href +']'+ link.innerText +'[/url]  ';
        i++;
        if(i >= newlinenum){
            i=0;
            str += '\n'
        }
    }
    console.log(str);
    copy(str);
}
function outputOriformat(frag){
    let node = frag.firstChild;
    let str = '';
    while(node !== null){
        if(node.nodeName == 'A'){
            str = str+'[url=' + node.href +']'+ node.innerText +'[/url]  ';
        } else if(node.nodeName == '#text'){
            if(node.data.match("^[ \xa0]+$") == null){
                str += node.data;
            }
        } else {
            if(node.nodeName == 'FONT'){
                str += dfs(node);
            } else {
                console.log("invalid nodeName:"+node.nodeName);
            }
        }
        node = node.nextSibling;
    }
    console.log(str);
    copy(str);
}

function dfs(root){
    let node = root.firstChild;
    let str = '';
    while(node != root){
        if(node.nodeName == 'A'){
            str = str+'[url=' + node.href +']'+ node.innerText +'[/url]  ';
        } else if(node.nodeName == '#text'){
            if(node.data.match("^[ \xa0]+$") == null){
                str += node.data;
            }
        } else {
            if(node.nodeName == 'FONT'){
                node = node.firstChild;
                continue;
            } else {
                console.log("invalid nodeName:"+node.nodeName);
            }
        }
        while(node.nextSibling == null){
            node = node.parentNode;
            if(node == root){
                return str;
            }
        }
        node = node.nextSibling;
    }
    return str;
}
function copy(word){
    let k = document.createElement("textarea");
    k.value = word;
    document.lastChild.append(k);
    k.select();
    document.execCommand("Copy");
    document.lastChild.removeChild(k);
}



    // Your code here...
})();