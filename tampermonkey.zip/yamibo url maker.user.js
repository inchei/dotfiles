// ==UserScript==
// @name         yamibo url maker
// @namespace    w-yamibo-manga-resort
// @version      0.2.4
// @description  convert yamibo's manga search list to bbs url list
// @author       You
// @include      https://bbs.yamibo.com/search.php?*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=undefined.
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';
const regexStr = '第(\\d+)話';
const newlinenum = 20;
const hitword = "!!!!!";
const pagelimit = 3;
let results = [];
let lists;

class Result{
    constructor(chap, tid, title, e){
        this.chap = chap;
        this.tid = tid;
        this.e = e;
        this.title = title;
    }
}
initEle();
mergepage().then(()=>{
    lists = document.getElementsByClassName("xs3");
    EletoResult(regexStr);
    output();
});

async function PmRequest(url){
    return new Promise(function(resolve){
        let a = new XMLHttpRequest();
        a.open("get", url, true);
        a.responseType = 'document';
        a.onload = function(){
            resolve(a.responseXML);
        }
        a.send();
    });
}
async function mergepage(){
    return new Promise(async (resolve)=>{
        let pagegroup = document.getElementsByClassName("pg");
        if(pagegroup.length == 0){
            return resolve(0);
        }
        let nowpage = pagegroup[0].getElementsByTagName("strong")[0];
        if(nowpage.innerHTML !== '1'){
            return resolve(0);
        }
        let pagelabel = pagegroup[0].getElementsByTagName("label")[0];
        let pagenum = pagelabel.innerText.match(/(\d+)/)[1];
        pagenum = parseInt(pagenum);
        let pagelinks = pagegroup[0].getElementsByTagName("a");
        if(pagenum > pagelimit){
            console.log("overlimit, page is "+pagenum);
            return resolve(-1);
        } else {
            let threadsul = document.getElementById("threadlist").children[0];
            if(pagelinks.length > pagelimit){
                console.log("error overlimit");
                return resolve(-1);
            }
            for(let link of pagelinks){
                if(link.className !== 'nxt'){
                    await PmRequest(link.href).then((body)=>{
                        let pbws = body.getElementsByClassName("pbw");
                        for(let pbw of pbws){
                            let li = document.importNode(pbw, true);
                            threadsul.append(li);
                        }
                    });
                }
            }
            resolve(1);
        }
    })
}

function EletoResult(regex){
    let r = new RegExp(regex);
    if(results.length == 0){
        for(let title of lists){
            let href = title.children[0].href;
            let tid = title.parentElement.id;
            let t = title.innerText;
            let chap = getchap(title.innerText, r);
            let e = document.createElement("span");
            title.append(e);
            e.innerHTML = chap;
            let result = new Result(chap, tid, t, e);
            results.push(result);
        }
    } else {
        console.clear();
        for(let result of results){
            let chap = getchap(result.title, r);
            result.chap = chap;
            result.e.innerHTML = chap;
        }
    }
}
function getchap(title, r){
    let match = r.exec(title);
    let chap;
    if(match === null){
        chap = hitword;
        console.log("invalid chap:" + title);
    } else {
        chap = match[1];
        chap = chtoint(chap);
        if(chap.length < 2){
            chap = '0' + chap;
        }
        if(match.length > 2){
            for(let pos = 2; pos < match.length; pos++){
                if(match[pos] == undefined){
                    continue;
                }
                chap += match[pos];
            }
        }
    }
    return chap;
}

function chtoint(chap){
    let num = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九']
    let hun = '百';
    let ten = '十';
    let newchap = '';
    if(chap[0] == ten){newchap += 1};
    for(let i = 0; i < 10; i++){
        if(chap[0] == num[i]){
            newchap += i.toString();
            break;
        }
    }
    if(newchap == ''){
        return chap;
    } else {
        for(let pos = 1; pos < chap.length; pos++){
            if(chap[pos] == hun || chap[pos] == ten){
                continue;
            } else {
                for(let i = 0; i < 10; i++){
                    if(chap[pos] == num[i]){
                        newchap += i.toString();
                        break;
                    } else if(i == 9) {
                        return chap;
                    }
                }
            }
        }
        let tail = chap[chap.length-1];
        if(tail == hun){
            newchap += '00';
        } else if (tail == ten){
            newchap += '0';
        }
    }
    return newchap;
}


function sortchap(a, b){
    if(a.chap > b.chap){
        return 1;
    } else if (a.chap < b.chap){
        return -1;
    } else {
        console.log("same chap:"+a.title+" and "+b.title);
        return 0;
    }
}
function sortid(a, b){
    if(a.tid > b.tid){
        return 1;
    } else {
        return -1;
    }
}
function copy(word){
    let k = document.createElement("textarea");
    k.value = word;
    document.lastChild.append(k);
    k.select();
    document.execCommand("Copy");
    document.lastChild.removeChild(k);
}
function output(){
    results.sort(sortid);
    let str = '';
    let i = 0;
    for(let result of results){
        if(result.chap == hitword){
            console.log("invalid output:"+result.title);
            }
        str = str+'[url=https://bbs.yamibo.com/thread-'+result.tid
            +'-1-1.html]'+result.chap+'[/url]  ';
        i++;
        if(i >= newlinenum){
            i=0;
            str += '\n'
        }
    }
    copy(str);
    console.log(str);
}


function initEle(){
    let head = document.getElementsByTagName("head")[0];
    let body = document.getElementsByTagName("body")[0];

    let styleEle = document.createElement("style");
    styleEle.type = "text/css";
    let styleCont = `
    .regexin {
    position: fixed;
    top: 80px;
    right: 10px;
    }
    .hide {
    display: none;
    }
    `;
    styleEle.innerHTML = styleCont;
    head.appendChild(styleEle);

    let regexDiv = document.createElement("div");
    let regexIn = document.createElement("input");
    regexIn.placeholder = '第(\\d+)話';
    regexIn.addEventListener("keydown", (e)=>{
        if(e.keyCode == 13){
            EletoResult(regexIn.value);
        }
    });

    let changeBtn = document.createElement("button");
    changeBtn.innerHTML = "change";
    changeBtn.addEventListener("click", ()=>{
        EletoResult(regexIn.value)
    });
    let resetBtn = document.createElement("button");
    resetBtn.innerHTML = "reset";
    resetBtn.addEventListener("click", ()=>{
        EletoResult(regexStr);
        regexIn.value = '';
    });
    let sureBtn = document.createElement("button");
    sureBtn.innerHTML = "output";
    sureBtn.addEventListener("click", ()=>output());
    //regexDiv.classList.add("regexin", "hide");
    regexDiv.classList.add("regexin");
    regexDiv.append(regexIn , changeBtn, resetBtn, sureBtn);
    body.append(regexDiv);
}




    // Your code here...
})();