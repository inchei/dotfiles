// ==UserScript==
// @name         矫正 b 站自动连播按钮 - 分P、合集、单视频开关分别独立
// @namespace    https://maxchang.me
// @version      0.4
// @description  关于我不想要哔哩哔哩自动连播只想在分 P 中跳转但是阿 b 把他们混为一谈这件事。
// @author       MaxChang3
// @match        https://www.bilibili.com/video/*
// @match        https://www.bilibili.com/list/*
// @icon         https://www.bilibili.com/favicon.ico
// @grant        GM_setValue
// @grant        GM_getValue
// @downloadURL https://update.greasyfork.org/scripts/451504/%E7%9F%AB%E6%AD%A3%20b%20%E7%AB%99%E8%87%AA%E5%8A%A8%E8%BF%9E%E6%92%AD%E6%8C%89%E9%92%AE%20-%20%E5%88%86P%E3%80%81%E5%90%88%E9%9B%86%E3%80%81%E5%8D%95%E8%A7%86%E9%A2%91%E5%BC%80%E5%85%B3%E5%88%86%E5%88%AB%E7%8B%AC%E7%AB%8B.user.js
// @updateURL https://update.greasyfork.org/scripts/451504/%E7%9F%AB%E6%AD%A3%20b%20%E7%AB%99%E8%87%AA%E5%8A%A8%E8%BF%9E%E6%92%AD%E6%8C%89%E9%92%AE%20-%20%E5%88%86P%E3%80%81%E5%90%88%E9%9B%86%E3%80%81%E5%8D%95%E8%A7%86%E9%A2%91%E5%BC%80%E5%85%B3%E5%88%86%E5%88%AB%E7%8B%AC%E7%AB%8B.meta.js
// ==/UserScript==

(function () {
    'use strict'
    // 自定义 logger
    const logger = {
        log: (...args) => console.log('[Correct-Next-Button]', ...args),
        error: (...args) => console.error('[Correct-Next-Button]', ...args),
    }
    const type = { VIDEO: 'video', MULTIPART: 'multipart', COLLECTION: 'collection' }
    const correctNextButton = (app) => {
        const videoData = app.videoData
        const { videos: videosCount } = videoData
        const pageType = videosCount > 1 ? type.MULTIPART : (app.isSection ? type.COLLECTION : type.VIDEO)
        const pageStatus = app.continuousPlay
        const userStatus = GM_getValue(pageType)
        if (userStatus == undefined) {
            GM_setValue(pageType, pageStatus)
        } else if (pageStatus != userStatus) {
            app.setContinuousPlay(userStatus)
        }
        logger.log(pageType, {
            'collection': GM_getValue(type.COLLECTION),
            'multipart': GM_getValue(type.MULTIPART),
            'video': GM_getValue(type.VIDEO)
        })
        document.querySelector('.switch-btn').addEventListener('click', () => {
            GM_setValue(pageType, !app.continuousPlay)
        })
    }
    const main = () => {
        if (location.href.startsWith('https://www.bilibili.com/medialist/play/')) {
            // todo
        } else {
            let interval = setInterval(() => {
                let app = document.querySelector('#app')
                if (app?.__vue__?.videoData) {
                    clearInterval(interval)
                    correctNextButton(app.__vue__)
                    // hook loadVideoData 保证从推荐视频加载新视频时重新判断视频类型
                    const __loadVideoData = app.__vue__.loadVideoData
                    app.__vue__.loadVideoData = () => new Promise((resolve, rejct) =>
                        __loadVideoData.call(this).then(
                            res => { correctNextButton(app.__vue__); resolve(res) },
                            error => rejct(error)
                        )
                    )
                }
            }, 500)
        }
    }
    main()
})()
