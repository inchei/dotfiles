// ==UserScript==
// @name        班固米吐彩虹
// @description 遇到彩虹，吃定彩虹
// @author      kk
// @version     0.1
// @match        *://bgm.tv/*
// @match        *://bangumi.tv/*
// @match        *://chii.in/*
// ==/UserScript==

const pattern = '/img/smiles/tv/102.gif'
const replacer = 'https://p.sda1.dev/26/69ac93d4dc8d425fafe7c3d70829b762/pixil-frame-0.png'
document.querySelectorAll(`img[src="${pattern}"]`).forEach(a => a.src=replacer)
document.querySelectorAll(`span[style="background-image: url('${pattern}');"]`).forEach(a => a.style=`background-image: url('${replacer}');`)
document.querySelectorAll('template').forEach(a => a.innerHTML = a.innerHTML.replace(pattern, replacer))