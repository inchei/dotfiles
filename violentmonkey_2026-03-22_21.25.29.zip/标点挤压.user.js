// ==UserScript==
// @name         标点挤压
// @namespace    text.spacing.trim
// @version      0.1
// @description  模拟标点挤压
// @author       Your Name
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 注入标点挤压样式（仅保留letter-spacing）
    const style = document.createElement('style');
    style.textContent = `
        .punctuation-trim {
            letter-spacing: -0.35em; /* 挤压强度，可按需微调 */
        }
    `;
    document.head.appendChild(style);

    // 标点处理核心逻辑
    (function() {
        if (document.body.lang.includes('en')) return;
        const rOpening = /[｛〔〈《「『【〘〖〝‘“｟«（]/; // 所有开始符号（包含引号）
        const rQuotes = /[‘“]/; // 单独匹配单引号、双引号（需要排除的开始符号）
        const rCloseing = /[｝、〕〉》」』】〙〗〟’”｠»）]/; // 结束符号
        const rStop = /[\u00b7\u2027\u30FB\uFF1A\uFF1B\u3001\u3002\uFF0C\uFF0E\uFF01\uFF1F]/; // 终止符号（包含冒号）
        const rColon = /[\uFF1A]/; // 单独匹配冒号
        const rPunctuation = new RegExp(
            [rOpening, rCloseing, rStop]
                .map(regex => regex.source)
                .join('|')
        );
        const rPuncs = new RegExp(`(${rPunctuation.source}){2,}`); // 连续2个及以上标点

        function handlePuncs(puncs) {
            // 拆分连续标点为对象数组
            const puncList = puncs[0].split('').map(punc => {
                let type = null;
                const rTypes = { opening: rOpening, closeing: rCloseing, stop: rStop };
                for (const typeName in rTypes) {
                    if (rTypes[typeName].test(punc)) {
                        type = typeName;
                        break;
                    }
                }
                return {
                    type,
                    value: punc,
                    trimed: false,
                    isColon: rColon.test(punc), // 标记是否为冒号
                    isQuote: rQuotes.test(punc) // 标记是否为单/双引号
                };
            });

            // 标记需要挤压的标点
            function trimPunc(punc) {
                if (!punc.trimed) {
                    punc.trimed = true;
                    punc.value = `<span class="punctuation-trim">${punc.value}</span>`;
                }
            }

            // 应用挤压规则
            puncList.forEach((current, index) => {
                const prev = index > 0 ? puncList[index - 1] : { type: null, isColon: false };
                const next = index < puncList.length - 1 ? puncList[index + 1] : { type: null, isQuote: false };

                // 原有规则：连续终止符、连续开始符、连续结束符等
                if (current.type === 'stop') {
                    if (next.type === 'closeing') trimPunc(current);
                    else if (next.type === 'opening' && !next.isQuote) trimPunc(prev); // 排除引号场景
                } else if (current.type === 'opening' && next.type === 'opening' && !next.isQuote) {
                    trimPunc(current); // 排除连续引号场景
                } else if (current.type === 'closeing') {
                    if (next.type === 'closeing' || next.type === 'stop') trimPunc(current);
                }

                // 规则1：结束符号+开始符号（仅挤压结束符号，排除开始符号是引号的情况）
                if (current.type === 'closeing' && next.type === 'opening') {
                    trimPunc(current);
                }

                // 规则2：冒号+开始符号（仅挤压冒号，且开始符号不是引号时才处理）
                if (current.isColon && next.type === 'opening' && !next.isQuote) {
                    trimPunc(current); // 只挤压冒号（排除冒号+单/双引号）
                }
            });

            // 拼接处理后的结果
            return puncList.map(punc => punc.value).join('');
        }

        function findPunctuation(string) {
            let puncs;
            let processed = '';
            while ((puncs = rPuncs.exec(string))) {
                processed += string.substring(0, puncs.index) + handlePuncs(puncs);
                string = string.substring(puncs.index + puncs[0].length);
            }
            return processed + string;
        }

        window.PunctuationTrim = html => findPunctuation(html);
    }());

    // 处理目标元素
    function processElements() {
        const targetSelectors = 'p, article, div, span, h1, h2, h3, h4, h5, h6';
        const elements = document.querySelectorAll(targetSelectors);

        elements.forEach(el => {
            // 排除可编辑元素
            if (['INPUT', 'TEXTAREA', 'SELECT'].includes(el.tagName)) return;
            // 处理标点
            const originalHtml = el.innerHTML;
            el.innerHTML = window.PunctuationTrim(originalHtml);
        });
    }

    // 页面加载完成后执行
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', processElements);
    } else {
        processElements();
    }

    // 监听动态内容
    const observer = new MutationObserver((mutations) => {
        mutations.forEach(mutation => {
            mutation.addedNodes.forEach(node => {
                if (node.nodeType === 1) {
                    const targetSelectors = 'p, article, div, span, h1, h2, h3, h4, h5, h6';
                    node.querySelectorAll(targetSelectors).forEach(el => {
                        if (!['INPUT', 'TEXTAREA', 'SELECT'].includes(el.tagName)) {
                            el.innerHTML = window.PunctuationTrim(el.innerHTML);
                        }
                    });
                }
            });
        });
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: false,
        characterData: false
    });
})();
