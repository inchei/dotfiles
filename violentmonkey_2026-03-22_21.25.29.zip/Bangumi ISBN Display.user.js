// ==UserScript==
// @name         Bangumi ISBN Display
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Infobox的ISBN显示
// @author       AE
// @match        https://bgm.tv/subject/*
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function () {
    'use strict';

    // 貌似各种库都比较草台，还是从这里拿定义比较好
    // https://www.isbn-international.org/range_file_generation
    // 这个XML目前大概210K
    // 前端工具就当个玩具，减少数据量。感觉后端分段比较好。
    // 制作数据，需要“// @grant        GM_xmlhttpRequest”，制作后注释掉
    function make_ISBN_range_data() {
        const need_def_test = `
978-0 English language
978-1 English language
978-2 French language
978-3 German language
978-4 Japan
978-7 China, People's Republic
978-88 Italy
978-89 Korea, Republic
978-962 Hong Kong, China
978-986 Taiwan
979-8 United States
979-10 France
979-11 Korea, Republic
`;
        const need_def_test2 = `978-4 Japan`;
        const need = need_def_test2.trim().split("\n").map(line => line.substring(0, line.indexOf(' ')));
        console.log(need);
        const range_file_url = "https://www.isbn-international.org/export_rangemessage.xml";
        GM.xmlHttpRequest({ url: range_file_url }).then(r => {

            const parser = new DOMParser();
            const xml = parser.parseFromString(r.responseText, "application/xml");
            console.log()
            const groups = Array.from(xml.querySelectorAll("Group"));
            const groups_need = groups.filter(g => {
                const prefix = g.querySelector("Prefix").innerHTML;
                return need.includes(prefix)
            }).map(group => {
                const obj = {};
                Array.from(group.children).forEach(e => {
                    if (e.children.length == 0) { obj[e.nodeName.toLowerCase()] = e.innerHTML; }
                    else {
                        // Rules
                        obj[e.nodeName.toLowerCase()] = Array.from(e.children).map(rule => {
                            const obj = {};
                            Array.from(rule.children).forEach(e => {
                                obj[e.nodeName.toLowerCase()] = e.innerHTML;
                            });
                            return obj;
                        });
                    }
                });
                return obj
            });

            console.log(groups_need);
        });
    }
    // make_ISBN_range_data();


    const ISBN_range_data = [
        {
            "prefix": "978-4",
            "agency": "Japan",
            "rules": [
                {
                    "range": "0000000-1999999",
                    "length": "2"
                },
                {
                    "range": "2000000-6999999",
                    "length": "3"
                },
                {
                    "range": "7000000-8499999",
                    "length": "4"
                },
                {
                    "range": "8500000-8999999",
                    "length": "5"
                },
                {
                    "range": "9000000-9499999",
                    "length": "6"
                },
                {
                    "range": "9500000-9999999",
                    "length": "7"
                }
            ]
        }
    ];

    // https://isbn.jpo.or.jp/index.php/fix__ref_pub/
    // 手抄了一些眼熟的。乱七八糟的比较多，需要筛选。
    const ISBN_publisher_data_Japan = `
04 KADOKAWA
06 講談社
07 主婦の友社
08 集英社
09 小学館
10 新潮社
15 早川書房
299 宝島社
7966 宝島社
7973 SBクリエイティブ
8002 宝島社
8019 竹書房
8124 竹書房
8156 SBクリエイティブ
8291 富士見書房
8402 アスキー・メディアワークス
88063 宝島社
88475 竹書房
89052 SBクリエイティブ
930795 SBクリエイティブ
`.trim().split("\n").map(l => {
        const i = l.indexOf(" ");
        return { id: l.substring(0, i), name: l.substring(i + 1) }
    });
    console.log(ISBN_publisher_data_Japan)


    function ISBN_min(isbn_represent) {
        return isbn_represent.replaceAll("-", "");
    }

    function ISBN_check_digit(isbn) {
        let c = 0;
        for (let n = 0; n < 12; n += 2) {
            c += parseInt(isbn[n]) + 3 * parseInt(isbn[n + 1]);
        }
        const check = ((10 - c % 10) % 10);
        return String(check);
    }

    function ISBN_verify(isbn) {
        if (isbn.length != 13) return false;
        const check = ISBN_check_digit(isbn);
        if (check != isbn[12]) { return false; }
        return true;
    }

    // 只看9位，最后一位可以错着不管
    function ISBN10_check_digit(isbn10) {
        let c = 0;
        for (let n = 0; n < 9; n += 1) {
            c += (10 - n) * isbn10[n];
        }
        c = (11 - c % 11) % 11;
        const check = (c === 10) ? 'X' : String(c);
        return check;
    }

    function ISBN10_get(isbn) {
        if (!isbn.startsWith("978")) { throw "Cannot generate ISBN10: " + isbn; }
        const check = ISBN10_check_digit(isbn.substring(3));
        return isbn.substring(3, 12) + check;
    }

    function ISBN_parse(isbn) {
        // hyphenation: pre group publisher title check
        const pre = { value: isbn.substring(0, 3) };

        const range_data = ISBN_range_data.find(x => {
            const y = pre.value + "-" + isbn.substring(3, 3 + x.prefix.length - 4);
            return x.prefix == y;
        });
        if (range_data) {

            const group = { value: range_data.prefix.substring(4), desc: range_data.agency };
            let progress = 3 + group.value.length;
            const left = isbn.substring(progress)
            const publisher_length = range_data.rules.find(rule => {
                const range = rule.range.split("-");
                if (range[0] <= left && left <= range[1]) { return true; }
            }).length;
            const publisher = { value: left.substring(0, publisher_length) };
            if (group.desc == "Japan") {
                const v = ISBN_publisher_data_Japan.find(x => x.id == publisher.value);
                if (v) { publisher.desc = v.name; }
            }
            const title = { value: left.substring(publisher_length, left.length - 1) }

            return [pre, group, publisher, title, { value: isbn.substring(12), desc: "校验位" }];

        } else {
            return [pre, { value: isbn.substring(3, 12) }, { value: isbn.substring(12) }];
        }
    }


    // bangumi
    function getInfoboxValue(str) {
        return str.substring(str.indexOf(":") + 1).trim();
    }
    const infos = document.querySelectorAll("#infobox>li>.tip");
    [].forEach.call(infos, (info) => {
        if (info.innerText.indexOf("ISBN") == 0) {
            const add = [];
            const li = info.parentNode;
            const value = getInfoboxValue(li.innerText);

            const isbn = ISBN_min(value);
            if (!ISBN_verify(isbn)) {
                console.log("非法值");
                return;
            }
            const isbn_parsed = ISBN_parse(isbn);
            console.log(isbn_parsed);
            const isbn_parsed_HTML = isbn_parsed.map(x => `<span class="x-tooltip">${x.value}${x.desc ? "<span class='x-tooltiptext'>" + x.desc + "</span>" : ''}</span>`).join("-");
            add.push({ key: "ISBN", value: isbn_parsed_HTML });
            add.push({ key: "ISBN 13", value: isbn });
            if (isbn.startsWith("978")) {
                const isbn10 = ISBN10_get(isbn);
                add.push({ key: "ISBN 10", value: isbn10 });
            }

            li.insertAdjacentHTML(
                "afterend",
                add.map(x => `<li><span class="tip">┠ ${x.key}: </span>${x.value}</li>`).join("")
            )
        }
    })

    // tooltip 随便抄的 效果不怎么样

    const styleString = `
/* Tooltip container */
.x-tooltip {
  position: relative;
  display: inline-block;
}

/* Tooltip text */
.x-tooltip .x-tooltiptext {
  visibility: hidden;
  text-align: center;
  width: max-content;
  padding: 5px;
  border-radius: 6px;
  background-color: #555;

  /* Position the tooltip text */
  position: absolute;
  z-index: 1;
  bottom: 125%;
  left: 50%;
  margin-left: -2em;

  /* Fade in tooltip */
  opacity: 0;
  transition: opacity 0.3s;
}

/* Tooltip arrow */
.x-tooltip .x-tooltiptext::after {
  content: "";
  position: absolute;
  top: 100%;
  left: 50%;
  margin-left: -5px;
  border-width: 5px;
  border-style: solid;
  border-color: #555 transparent transparent transparent;
}

/* Show the tooltip text when you mouse over the tooltip container */
.x-tooltip:hover .x-tooltiptext {
  visibility: visible;
  opacity: 1;
}
    `;

    const style = document.createElement('style');
    style.textContent = styleString;
    document.head.append(style);
})();