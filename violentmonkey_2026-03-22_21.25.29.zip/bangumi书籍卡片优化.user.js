// ==UserScript==
// @name         bangumi书籍卡片优化
// @version      2025-08-04
// @description  对于列表、时间线中的书籍条目，查询信息后，显示出分类（小说/漫画/小说系列/漫画系列…），使用原文标题，显示插画师，优先使用书系替代出版社
// @author       AE
// @match        https://bgm.tv/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';


    // list items for:
    // /person/*/works
    // /book/browser
    const elementid_regex = /^item_(\d+)$/;
    const url_regex = /^https:\/\/bgm.tv\/subject\/(\d+)$/;
    const items = document.querySelectorAll(".item");
    const icon_book = `<span class="ico_subject_type subject_type_1 ll"></span>`;
    items.forEach(async (li) => {

        const match = li.id.match(elementid_regex);
        if (match) {
            const subject_id = match[1];
            const res = await fetch("https://api.bgm.tv/v0/subjects/" + subject_id);
            if (res.status != 200) {
                console.log("nsfw?" + subject_id);
                return;
            }
            const data = await res.json();
            if (data.platform != "小说" && data.platform != "漫画") return;
            //console.log(data)
            const { subject_type, name, tip } = GetDisplay(data);

            li.querySelector("h3").innerHTML = `
            ${icon_book}
            <span class="badge_job" style="background:#ffa41e!important">${subject_type}</span>
            <a href="/subject/${subject_id}" class="l">${data.name}<a>`;
            li.querySelector(".info.tip").innerHTML = tip;
        }
    });


    // timeline
    function ModifyCards() {
        const cards = document.querySelectorAll(".card");
        cards.forEach(async (card) => {
            const match = card.querySelector("a").href.match(url_regex);
            if (match) {
                if (card.getAttribute("data-bookcard-checked")) return;
                card.setAttribute("data-bookcard-checked", "1");
                const subject_id = match[1];
                const res = await fetch("https://api.bgm.tv/v0/subjects/" + subject_id);
                if (res.status != 200) {
                    console.log("nsfw?" + subject_id);
                    return;
                }
                const data = await res.json();
                if (data.platform != "小说" && data.platform != "漫画") return;
                //console.log(data)
                const { subject_type, name, tip } = GetDisplay(data);
                card.querySelector(".title").innerHTML = `
            <span class="badge_job" style="background:#ffa41e!important">${subject_type}</span>
            <a href="/subject/${subject_id}">${data.name}<a>`;
                card.querySelector(".info.tip").innerHTML = tip;
            }
        });
    }
    ModifyCards();
    const tml = document.getElementById("tmlContent");
    if (tml) {
        const config = { childList: true, subtree: true };
        const observer = new MutationObserver(function (mutationsList, observer) {
            //console.log(mutationsList)
            observer.disconnect();
            ModifyCards();
            setTimeout(() => { observer.observe(tml, config); }, 1);
        });
        observer.observe(tml, config);
    }


    // common
    function GetDisplay(data) {
        let tip_items = [];
        if (data.date) tip_items.push(data.date);
        switch (data.platform) {
            case "小说":
                {
                    let creators = FindCreators(data, ["作者", "插图", "原作"]).join(" / ");
                    if (creators) tip_items.push(creators);
                    let label_kv = FindFallback(data, ["书系", "文库", "出版社"]);
                    if (label_kv) { tip_items.push(label_kv.value); }
                }
                break;
            case "漫画":
                {
                    let creators = FindCreators(data, ["作者", "作画", "原作"]).join(" / ");
                    if (creators) tip_items.push(creators);
                    let label_kv = FindFallback(data, ["连载杂志", "书系", "出版社"]);
                    if (label_kv) { tip_items.push(label_kv.value); }
                    let chapter_kv = FindFallback(data, ["话数"]);
                    if (chapter_kv) { tip_items.push(chapter_kv.value + "话"); }
                }
                break;
        }

        const tip = tip_items.join("&nbsp;/&nbsp;");
        const subject_type = data.platform + (data.series ? "系列" : "");
        const name = data.name
        return { subject_type, name, tip };
    }

    function FindCreators(data, arr) {
        const r = [];
        for (const x of arr) {
            const kv = data.infobox.find(y => y.key == x);
            if (kv) r.push(kv);
        }
        if (r.length == 1) { return [r[0].value]; }
        return r.map(kv => `${kv.key}・${kv.value}`);
    }
    function FindFallback(data, arr) {
        for (const x of arr) {
            const kv = data.infobox.find(y => y.key == x)
            if (kv) {
                return kv;
            }
        }
        return null;
    }
})();