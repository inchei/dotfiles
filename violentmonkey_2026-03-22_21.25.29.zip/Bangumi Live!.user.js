// ==UserScript==
// @name         Bangumi Live!
// @version      1.0.0
// @description  实时刷新帖子、共享输入状态，让Bangumi成为即时通讯平台✨
// @author       wataame
// @license      MIT
// @match         *://bangumi.tv/group/topic/*
// @match         *://bgm.tv/group/topic/*
// @match         *://chii.in/group/topic/*
// @match         *://bangumi.tv/subject/topic/*
// @match         *://bgm.tv/subject/topic/*
// @match         *://chii.in/subject/topic/*
// @match         *://bangumi.tv/blog/*
// @match         *://bgm.tv/blog/*
// @match         *://chii.in/blog/*
// @match         *://bangumi.tv/ep/*
// @match         *://bgm.tv/ep/*
// @match         *://chii.in/ep/*
// @match         *://bangumi.tv/settings/privacy
// @match         *://bgm.tv/settings/privacy
// @match         *://chii.in/settings/privacy
// @connect         bgmpush.ry.mk
// ==/UserScript==

(function() {
    'use strict';
    // --- Configuration ---
    const WS_URL = 'wss://bgmpush.ry.mk';
    const RECONNECT_DELAY = 5000;
    const INTERACTION_COOLDOWN = 6000;
    const TYPING_THROTTLE_DELAY = 3000;

    const PAGE_TYPES = {
        group:   { urlRe: /\/group\/topic\/(\d+)/,  likeType: 8,  subReplyType: 'group' },
        subject: { urlRe: /\/subject\/topic\/(\d+)/, likeType: 10, subReplyType: 'subject' },
        blog:    { urlRe: /\/blog\/(\d+)/,           likeType: 15, subReplyType: 'blog' },
        ep:      { urlRe: /\/ep\/(\d+)/,             likeType: 11, subReplyType: 'ep' },
    };

    // --- State ---
    let ws;
    let pageInfo;
    let emojiMap = {};
    const recentlyInteractedPostIds = new Set();
    const pendingHighlights = new Set();
    const originalTitle = document.title;
    let originalFaviconURL = '';
    const newFaviconURL = '/img/smiles/tv/82.gif';
    let isTitleNotifying = false;
    let unreadPostCount = 0;
    const selfUID = String(window.CHOBITS_UID || '0');
    let selfNickname = '';
    let typingTimer = null;
    let isTyping = false;
    let typingIndicatorElement = null;
    let formhash = '';
    let notifierElement = null;
    let notifierObserver = null;
    let notifierHideTimer = null;
    let shouldStartNotifierCountdown = false;
    let mainReplyTemplate = null;
    let subReplyTemplate = null;
    let SETTINGS = {};

    // --- Settings Management ---
    const SETTINGS_KEY = 'BgmPush_Settings';

    function getSettings() {
        const defaults = {
            realtimeEnabled: true,
            typingEnabled: true,
        };
        try {
            const stored = localStorage.getItem(SETTINGS_KEY);
            const loaded = stored ? JSON.parse(stored) : {};
            return { ...defaults, ...loaded };
        } catch (e) {
            console.error('[BGM-Push] Failed to load settings, using defaults.', e);
            return defaults;
        }
    }

    function saveSettings(newSettings) {
        try {
            localStorage.setItem(SETTINGS_KEY, JSON.stringify(newSettings));
        } catch (e) {
            console.error('[BGM-Push] Failed to save settings.', e);
        }
    }

    // --- Helper Functions ---
    function detectPage() {
        const path = window.location.pathname;
        for (const [type, config] of Object.entries(PAGE_TYPES)) {
            const match = path.match(config.urlRe);
            if (match) {
                return { type: type, id: match[1], config: config };
            }
        }
        return null;
    }

    function setFavicon(url) {
        let link = document.querySelector("link[rel~='icon']");
        if (!link) {
            link = document.createElement('link');
            link.rel = 'icon';
            document.head.appendChild(link);
        }
        link.href = url;
    }

    function injectCSS() {
        const style = document.createElement('style');
        style.textContent = `
            :root {
              --rtc-highlight-bg: #fff5f5; --rtc-highlight-border: #f09199;
              --rtc-self-highlight-bg: #f5faff; --rtc-self-highlight-border: #91bcf0;
              --rtc-flash-bg: #ffe8e8; --rtc-notifier-bg: #f09199;
              --rtc-notifier-text: white;
              --rtc-color-connected: #4CAF50;
              --rtc-color-connecting: #FFC107;
              --rtc-color-disconnected: #F44336;
            }
            html[data-theme="dark"] {
              --rtc-highlight-bg: #2c1a1f; --rtc-highlight-border: #a15c63;
              --rtc-self-highlight-bg: #1a232c; --rtc-self-highlight-border: #5c7ca1;
              --rtc-flash-bg: #522; --rtc-notifier-bg: #a15c63;
            }
            .rtc-pop-in { animation: rtc-pop-in 0.5s ease-out; }
            @keyframes rtc-pop-in { from { opacity: 0; transform: scale(0.98); } to { opacity: 1; transform: scale(1); } }
            .new-comment-highlight { background-color: var(--rtc-highlight-bg) !important; border-left: 3px solid var(--rtc-highlight-border); margin-left: -3px; transition: background-color 2s ease-out; }
            .self-new-comment-highlight { background-color: var(--rtc-self-highlight-bg) !important; border-left: 3px solid var(--rtc-self-highlight-border); margin-left: -3px; transition: background-color 2s ease-out; }
            .updated-comment-highlight, .likes-updated-highlight { animation: rtc-flash-pink 1.5s ease-out; }
            @keyframes rtc-flash-pink { 0% { background-color: var(--rtc-flash-bg); } 100% { background-color: transparent; } }
            .rtc-notifier { position: fixed; top: 80px; left: 50%; transform: translateX(-50%); padding: 8px 16px; background-color: var(--rtc-notifier-bg); color: var(--rtc-notifier-text); font-size: 14px; font-weight: bold; border-radius: 20px; cursor: pointer; z-index: 9999; box-shadow: 0 2px 10px rgba(0,0,0,0.2); opacity: 0; visibility: hidden; transition: opacity 0.3s ease, top 0.3s ease, visibility 0.3s; }
            .rtc-notifier.visible { top: 100px; opacity: 1; visibility: visible; }
            .rtc-avatar-indicator { transition: border-color 0.5s, box-shadow 0.3s ease-out; border: 2px solid transparent; border-radius: 5px; box-sizing: border-box; }
            .rtc-avatar-indicator.connected { border-color: var(--rtc-color-connected); }
            .rtc-avatar-indicator.connecting { border-color: var(--rtc-color-connecting); animation: rtc-avatar-pulse 2s infinite; }
            .rtc-avatar-indicator.disconnected { border-color: var(--rtc-color-disconnected); }
            @keyframes rtc-avatar-pulse { 0% { box-shadow: 0 0 0 0px rgba(255, 193, 7, 0.7); } 70% { box-shadow: 0 0 0 5px rgba(255, 193, 7, 0); } 100% { box-shadow: 0 0 0 0px rgba(255, 193, 7, 0); } }
            .rtc-typing-indicator { font-size: 12px; color: #888; margin-left: 10px; font-weight: normal; display: inline-block; vertical-align: middle; }
            html[data-theme="dark"] .rtc-typing-indicator { color: #bbb; }
            .rtc-typing-indicator .dot { display: inline-block; animation: rtc-blink 1.4s infinite both; width: 3px; height: 3px; background-color: #888; border-radius: 50%; margin: 0 1px; }
            html[data-theme="dark"] .rtc-typing-indicator .dot { background-color: #bbb; }
            .rtc-typing-indicator .dot:nth-child(2) { animation-delay: 0.2s; }
            .rtc-typing-indicator .dot:nth-child(3) { animation-delay: 0.4s; }
            @keyframes rtc-blink { 0% { opacity: 0.2; } 20% { opacity: 1; } 100% { opacity: 0.2; } }
            #rtc-settings-panel { margin-top: 20px; margin-bottom: 20px; }
            #rtc-settings-panel .settings { width: 100%; }
            #rtc-settings-panel .settings td { padding: 8px 5px; }
            #rtc-settings-panel .settings small.grey { color: #999; margin-left: 10px; }
            html[data-theme="dark"] #rtc-settings-panel .settings small.grey { color: #888; }
            #rtc-settings-panel input[type="checkbox"] { vertical-align: middle; }
            #rtc-settings-saved { color: var(--rtc-color-connected, #4CAF50); font-weight: bold; opacity: 0; transition: opacity 0.5s; margin-left: 15px; }
        `;
        document.head.appendChild(style);
    }

    function initializeStatusIndicator() {
        const avatarSpan = document.querySelector('#headerNeue2 .idBadgerNeue .avatar .avatarNeue');
        if (avatarSpan) {
            avatarSpan.classList.add('rtc-avatar-indicator');
            updateStatus('connecting');
            return true;
        }
        console.warn('[BGM-Push] Could not find user avatar element for status indicator.');
        return false;
    }

    function updateStatus(status) {
        const avatarSpan = document.querySelector('.rtc-avatar-indicator');
        if (!avatarSpan) return;
        const statusClasses = ['connected', 'connecting', 'disconnected'];
        statusClasses.forEach(s => avatarSpan.classList.remove(s));
        if (status) avatarSpan.classList.add(status);
        const titles = { connecting: "BGM-Push: 正在连接...", connected: "BGM-Push: 已连接", disconnected: "BGM-Push: 连接已断开，正在重试..." };
        const avatarLink = avatarSpan.closest('a.avatar');
        if (avatarLink) avatarLink.title = titles[status] || 'Bangumi Realtime Push';
    }

    function isElementInViewport(el) {
        if (document.hidden) return Promise.resolve(false);
        return new Promise(resolve => {
            const observer = new IntersectionObserver(([entry]) => {
                resolve(entry.isIntersecting);
                observer.disconnect();
            });
            observer.observe(el);
        });
    }

    function updatePageNotificationState() {
        if (document.hidden) {
            if (unreadPostCount > 0) {
                if (!isTitleNotifying) isTitleNotifying = true;
                document.title = `[${unreadPostCount}条新回复✨] ${originalTitle}`;
            }
        } else {
            if (isTitleNotifying) {
                isTitleNotifying = false;
                document.title = originalTitle;
                unreadPostCount = 0;
                setFavicon(originalFaviconURL);
            }
        }
    }

    function formatTimestamp(unixTimestamp) {
        const date = new Date(unixTimestamp * 1000);
        const year = date.getFullYear();
        const month = date.getMonth() + 1;
        const day = date.getDate();
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        return `${year}-${month}-${day} ${hours}:${minutes}`;
    }

    function createNotifier() {
        notifierElement = document.createElement("div");
        notifierElement.className = "rtc-notifier";
        document.body.appendChild(notifierElement);
    }

    function showNotifier(count, targetElement) {
        if (!notifierElement || !targetElement) return;
        if (notifierHideTimer) clearTimeout(notifierHideTimer);
        if (notifierObserver) notifierObserver.disconnect();
        shouldStartNotifierCountdown = false;

        notifierElement.textContent = `有新回复✨`;
        notifierElement.onclick = () => {
            targetElement.scrollIntoView({ behavior: "smooth", block: "center" });
            notifierElement.classList.remove("visible");
        };
        notifierElement.classList.add("visible");

        const startCountdown = () => {
            if (notifierHideTimer) clearTimeout(notifierHideTimer);
            notifierHideTimer = setTimeout(() => {
                notifierElement.classList.remove("visible");
                if (notifierObserver) notifierObserver.disconnect();
            }, 8000);
        };

        if (document.hidden) {
            shouldStartNotifierCountdown = true;
        } else {
            startCountdown();
        }

        notifierObserver = new IntersectionObserver(([entry]) => {
            if (entry.isIntersecting) {
                notifierElement.classList.remove("visible");
                if (notifierHideTimer) clearTimeout(notifierHideTimer);
                entry.target.observer.disconnect();
            }
        }, { threshold: 0.1 });
        notifierObserver.observe(targetElement);
    }

    function createTypingIndicator() {
        const replyTitle = document.querySelector('#new_comment h2.reply_title, #comment_list + .sub_title, #comment_list + hr + #reply_wrapper h2.reply_title');
        if (replyTitle) {
            typingIndicatorElement = document.createElement('span');
            typingIndicatorElement.className = 'rtc-typing-indicator';
            replyTitle.appendChild(typingIndicatorElement);
        }
    }

    function updateTypingIndicator(users) {
        if (!typingIndicatorElement) return;
        const typingUsers = users.filter(user => user.uid !== selfUID);
        if (typingUsers.length === 0) {
            typingIndicatorElement.innerHTML = '';
            return;
        }
        const names = typingUsers.map(u => u.nickname).slice(0, 2);
        let text = (typingUsers.length > 2) ? `${names.join('、')} 等人正在输入` : `${names.join('、')} 正在输入`;
        typingIndicatorElement.innerHTML = `${text}<span class="dot"></span><span class="dot"></span><span class="dot"></span>`;
    }

    function buildEmojiMap() {
        const template = document.getElementById('likes_reaction_menu');
        if (!template || !template.content) return;
        template.content.querySelectorAll("a[data-like-value]").forEach(a => {
            const value = a.dataset.likeValue;
            const img = a.querySelector("img.emoji");
            if (value && img) emojiMap[value] = img.src.split("/").pop().replace(".gif", "");
        });
    }

    function getFloorNumber(post, currentMainReplyCount) {
        const isSub = post.parentId && post.parentId != pageInfo.id;
        if (isSub) {
            const parentPostEl = document.getElementById(`post_${post.parentId}`);
            if (!parentPostEl) return "#?";
            const floorAnchor = parentPostEl.querySelector('.floor-anchor');
            const parentFloor = floorAnchor ? floorAnchor.textContent.replace("#", "").split("-")[0] : "?";
            const subReplyContainer = document.getElementById(`topic_reply_${post.parentId}`);
            const subCount = subReplyContainer ? subReplyContainer.querySelectorAll(".sub_reply_bg").length : 0;
            return `#${parentFloor}-${subCount + 1}`;
        }
        if (pageInfo.type === 'ep') {
            const allReplies = document.querySelectorAll("#comment_list > .row_reply, #comment_list > .row");
            return `#${allReplies.length + 1}`;
        }
        return `#${currentMainReplyCount + 1}`;
    }

    function createActionButtonsHTML(post, isSub) {
        const creatorId = String(post.creator.id);
        const mainId = isSub ? (post.mainID || pageInfo.id) : pageInfo.id;
        const relatedId = isSub ? post.parentId : post.id;
        const sub_reply = isSub ? 1 : 0;
        const ignoreButton = creatorId !== selfUID ? `<li><a href="javascript:void(0);" onclick="ignoreUser('${post.creator.username}','${formhash}')">绝交</a></li>` : "";
        return `
            <div class="action"><a href="javascript:void(0);" onclick="subReply('${pageInfo.config.subReplyType}', ${mainId}, ${relatedId}, ${isSub ? post.id : 0}, ${selfUID}, ${creatorId}, ${sub_reply})" class="icon" title="回复"><span class="ico ico_reply">&nbsp;</span><span class="title">回复</span></a></div>
            <div class="action dropdown"><a href="javascript:void(0);" class="icon like_dropdown" data-like-type="${pageInfo.config.likeType}" data-like-main-id="${mainId}" data-like-related-id="${post.id}" data-like-tpl-id="likes_reaction_menu"><span class="ico ico_like">&nbsp;</span><span class="title">贴贴</span></a></div>
            <div class="action dropdown"><a href="javascript:void(0);" class="icon"><span class="ico ico_more">...</span></a><ul>${ignoreButton}<li><a href="/report?type=${pageInfo.config.likeType}&id=${post.id}&keepThis=false&TB_iframe=true&height=215&width=450" title="报告疑虑" class="thickbox">报告疑虑</a></li></ul></div>`;
    }

    function createPostElementFromTemplate(post, currentMainReplyCount) {
        const isSub = post.parentId && post.parentId != pageInfo.id;
        const template = isSub ? subReplyTemplate : mainReplyTemplate;
        if (!template) return null;
        const newElement = template.cloneNode(true);
        newElement.id = `post_${post.id}`;
        newElement.dataset.itemUser = post.creator.username;
        newElement.classList.add('rtc-pop-in');
        const floorAnchor = newElement.querySelector('.floor-anchor');
        if (floorAnchor) {
            floorAnchor.textContent = getFloorNumber(post, currentMainReplyCount);
            floorAnchor.href = `#post_${post.id}`;
            const timeEl = floorAnchor.parentNode.childNodes[1];
            if (timeEl?.nodeType === Node.TEXT_NODE) timeEl.textContent = ` - ${formatTimestamp(post.createdAt)}`;
        } else {
            const smallTime = newElement.querySelector('.re_info small, .post_actions small');
            if (smallTime) smallTime.innerHTML = `<a href="#post_${post.id}" class="floor-anchor">${getFloorNumber(post, currentMainReplyCount)}</a> - ${formatTimestamp(post.createdAt)}`;
        }
        const avatarLink = newElement.querySelector('a.avatar');
        if(avatarLink) avatarLink.href = `/user/${post.creator.username}`;
        const avatarSpan = newElement.querySelector('span.avatarNeue');
        if(avatarSpan) avatarSpan.style.backgroundImage = `url('${post.creator.avatar.large}')`;
        const userLink = newElement.querySelector('.inner > .userInfo > strong > a, .inner > strong.userName > a, .inner > strong > a.l');
        if (userLink) {
            userLink.href = `/user/${post.creator.username}`;
            userLink.textContent = post.creator.nickname;
            userLink.className.split(' ').forEach(cls => { if (cls.startsWith('post_author_')) userLink.classList.remove(cls); });
            if (isSub) userLink.id = String(post.id);
            else userLink.classList.add(`post_author_${post.id}`);
        }
        const userSign = newElement.querySelector('.userInfo > .sign');
        if (userSign) userSign.textContent = `(${post.creator.sign || ''})`;
        const contentContainer = newElement.querySelector('.message, .cmt_sub_content, .reply_content > .message');
        if (contentContainer) contentContainer.innerHTML = post.contentHTML;
        const actionsContainer = newElement.querySelector('.post_actions.re_info, .re_info');
        if (actionsContainer) {
            const buttonsHTML = createActionButtonsHTML(post, isSub);
            actionsContainer.querySelectorAll('.action.dropdown, .action > a.icon[onclick], .action > a.icon > .ico_reply').forEach(btn => (btn.closest('.action') || btn.parentElement).remove());
            actionsContainer.insertAdjacentHTML('beforeend', buttonsHTML);
        }
        const likesGrid = newElement.querySelector('.likes_grid');
        if (likesGrid) {
            likesGrid.id = `likes_grid_${post.id}`;
            likesGrid.innerHTML = createReactionGridHTML(post.id, post.reactions);
        }
        const subReplyDiv = newElement.querySelector('.topic_sub_reply');
        if(subReplyDiv) {
            subReplyDiv.id = `topic_reply_${post.id}`;
            subReplyDiv.innerHTML = '';
        }
        return newElement;
    }

    function reinitializeBangumiScripts() {
        if (window.chiiLib?.likes?.init) window.chiiLib.likes.init();
        if (window.chiiLib?.widget?.dropdown) window.chiiLib.widget.dropdown();
        if (typeof window.tb_init === 'function') window.tb_init('a.thickbox, area.thickbox, input.thickbox');
    }

    function applyHighlight(element, className) {
        if (!element) return;
        element.classList.add(className);
        setTimeout(() => {
            element.style.backgroundColor = '';
            setTimeout(() => {
                element.classList.remove(className);
                element.style.borderLeft = '';
                element.style.marginLeft = '';
            }, 2000);
        }, 2000);
    }

    function applyFlash(element, className) {
        if (element) {
            element.classList.remove(className);
            void element.offsetWidth;
            element.classList.add(className);
        }
    }

    async function handleNewPosts(posts) {
        const isPageHidden = document.hidden;
        let mainReplyCount = document.querySelectorAll("#comment_list > .row_reply, #comment_list > .row").length;

        const createdElementsData = [];
        let hasDomChanges = false;

        for (const post of posts) {
            if (document.getElementById(`post_${post.id}`)) continue;

            // [MODIFIED] Check if the post author is in the ignore list
            if (window.data_ignore_users && (window.data_ignore_users.includes(String(post.creator.id)) || window.data_ignore_users.includes(post.creator.username))) {
                console.log(`[BGM-Push] Ignoring post from blocked user: ${post.creator.nickname}`);
                continue;
            }

            const isSub = post.parentId && post.parentId != pageInfo.id;
            if (!isSub) mainReplyCount++;

            const newElement = createPostElementFromTemplate(post, mainReplyCount);
            if (!newElement) continue;

            hasDomChanges = true;
            let parentElement = isSub ? document.getElementById(`topic_reply_${post.parentId}`) : document.getElementById('comment_list');
            if (parentElement) {
                if (pageInfo.type === 'ep') parentElement.prepend(newElement);
                else parentElement.appendChild(newElement);

                const isSelf = String(post.creator.id) === selfUID;
                createdElementsData.push({ el: newElement, isSelf: isSelf });
            }
        }

        if (hasDomChanges) reinitializeBangumiScripts();

        const nonSelfPosts = createdElementsData.filter(data => !data.isSelf);
        const newPostCount = nonSelfPosts.length;

        if (newPostCount > 0) {
            const firstNewElement = nonSelfPosts[0].el;

            if (isPageHidden) {
                showNotifier(newPostCount, firstNewElement);
            } else {
                const isFirstInView = await isElementInViewport(firstNewElement);
                if (!isFirstInView) {
                    showNotifier(newPostCount, firstNewElement);
                }
            }
        }

        for (const data of createdElementsData) {
            const isInViewport = await isElementInViewport(data.el);
            if (isInViewport) continue;

            if (data.isSelf) {
                applyHighlight(data.el, 'self-new-comment-highlight');
            } else {
                if (isPageHidden) {
                    pendingHighlights.add(data.el.id);
                } else {
                    applyHighlight(data.el, 'new-comment-highlight');
                }
            }
        }

        if (newPostCount > 0 && isPageHidden) {
            unreadPostCount += newPostCount;
            updatePageNotificationState();
            setFavicon(newFaviconURL);
        }
    }


    function handleDeletedPosts(postIds) {
        postIds.forEach(id => {
            const postElement = document.getElementById(`post_${id}`);
            if (postElement) postElement.innerHTML = '<div class="deleted_post" style="padding: 10px; color: #999;">[此回复已被删除]</div>';
        });
    }

    function createReactionGridHTML(postId, reactions) {
        if (!reactions || reactions.length === 0) return "";
        return reactions.map(reaction => {
            const emojiFile = emojiMap[reaction.value] || "15";
            const userNicknames = reaction.users.map(u => u.nickname).join(", ");
            return `<a class="item" href="javascript:void(0);" title="${userNicknames}" data-toggle="tooltip"><span class="emoji" style="background-image: url('/img/smiles/tv/${emojiFile}.gif');"></span><span class="num">${reaction.users.length}</span></a>`;
        }).join("");
    }

    function handleReactionUpdates(reactionUpdates) {
        reactionUpdates.forEach(update => {
            if (recentlyInteractedPostIds.has(update.postId)) return;
            const grid = document.getElementById(`likes_grid_${update.postId}`);
            if (grid) {
                grid.innerHTML = createReactionGridHTML(update.postId, update.reactions);
                applyFlash(grid, "likes-updated-highlight");
            }
        });
    }

    function handleUpdatedPosts(postUpdates) {
        postUpdates.forEach(update => {
            const postElement = document.getElementById(`post_${update.postId}`);
            if (!postElement) return;
            const contentEl = postElement.querySelector(".topic_content, .message, .cmt_sub_content, .reply_content > .message");
            if (contentEl) {
                contentEl.innerHTML = update.contentHTML;
                applyFlash(postElement, "updated-comment-highlight");
            }
        });
    }

    function handleServerMessage(event) {
        try {
            const message = JSON.parse(event.data);
            const currentPageKey = `${pageInfo.type}:${pageInfo.id}`;
            const messageKey = `${message.pageType}:${message.topicId}`;
            if (messageKey !== currentPageKey) return;
            switch (message.type) {
                case 'update':
                    const { data } = message;
                    if (data.newPosts?.length > 0) handleNewPosts(data.newPosts);
                    if (data.deletedPostIds?.length > 0) handleDeletedPosts(data.deletedPostIds);
                    if (data.updatedReactions?.length > 0) handleReactionUpdates(data.updatedReactions);
                    if (data.updatedPosts?.length > 0) handleUpdatedPosts(data.updatedPosts);
                    break;
                case 'typing_update':
                    updateTypingIndicator(message.users);
                    break;
            }
        } catch (error) { console.error('[BGM-Push] Error processing message:', error); }
    }

    function connect() {
        updateStatus("connecting");
        ws = new WebSocket(WS_URL);
        ws.onopen = () => {
            updateStatus("connected");
            ws.send(JSON.stringify({ type: "subscribe", pageType: pageInfo.type, topicId: pageInfo.id, userInfo: { uid: selfUID, nickname: selfNickname } }));
        };
        ws.onmessage = handleServerMessage;
        ws.onclose = () => {
            updateStatus("disconnected");
            setTimeout(connect, RECONNECT_DELAY);
        };
        ws.onerror = err => { console.error("[BGM-Push] WebSocket Error:", err); ws.close(); };
    }

    function initializeInteractionListeners() {
        document.body.addEventListener("click", e => {
            const likeButton = e.target.closest(".like_dropdown, .likes_grid .item");
            if (likeButton) {
                const post = likeButton.closest('[id^="post_"]');
                if (post) {
                    const postId = parseInt(post.id.replace("post_", ""), 10);
                    if (!isNaN(postId)) {
                        recentlyInteractedPostIds.add(postId);
                        setTimeout(() => recentlyInteractedPostIds.delete(postId), INTERACTION_COOLDOWN);
                    }
                }
            }
        }, true);

        document.addEventListener("visibilitychange", () => {
            updatePageNotificationState();

            if (!document.hidden && notifierElement && notifierElement.classList.contains('visible') && shouldStartNotifierCountdown) {
                if (notifierHideTimer) clearTimeout(notifierHideTimer);
                notifierHideTimer = setTimeout(() => {
                    notifierElement.classList.remove("visible");
                    if (notifierObserver) notifierObserver.disconnect();
                }, 8000);
                shouldStartNotifierCountdown = false;
            }

            if (!document.hidden && pendingHighlights.size > 0) {
                pendingHighlights.forEach(postId => {
                    const el = document.getElementById(postId);
                    if (el) applyHighlight(el, 'new-comment-highlight');
                });
                pendingHighlights.clear();
            }
        });

        const replyTextarea = document.getElementById('content');
        if (replyTextarea && SETTINGS.typingEnabled) {
            const sendTypingState = (state) => {
                if (ws?.readyState !== WebSocket.OPEN) return;
                ws.send(JSON.stringify({ type: state, pageType: pageInfo.type, topicId: pageInfo.id }));
            };
            replyTextarea.addEventListener('input', () => {
                clearTimeout(typingTimer);
                if (replyTextarea.value.trim().length > 0) {
                    if (!isTyping) {
                        sendTypingState('start_typing');
                        isTyping = true;
                    }
                    typingTimer = setTimeout(() => {
                        sendTypingState('stop_typing');
                        isTyping = false;
                    }, TYPING_THROTTLE_DELAY);
                } else {
                    if (isTyping) {
                        sendTypingState('stop_typing');
                        isTyping = false;
                    }
                }
            });
        }
    }

    function initializeSettingsPage() {
        const columnA = document.getElementById('columnA');
        if (!columnA) return;
        const settingsPanelHTML = `
            <div id="rtc-settings-panel">
                <form>
                    <table class="settings">
                        <tbody>
                            <tr><td colspan="2"><h2 class="subtitle">Bangumi Realtime Push 设置</h2></td></tr>
                            <tr>
                                <td valign="top" width="25%">启用实时更新</td>
                                <td valign="top"><input type="checkbox" id="rtc-setting-realtime"><small class="grey">关闭后，将停用所有实时推送功能。</small></td>
                            </tr>
                            <tr>
                                <td valign="top" width="25%">分享“正在输入”状态</td>
                                <td valign="top"><input type="checkbox" id="rtc-setting-typing"><small class="grey">关闭后，其他人将看不到你正在输入的状态。</small></td>
                            </tr>
                            <tr><td></td><td><span id="rtc-settings-saved">设置已保存!</span></td></tr>
                        </tbody>
                    </table>
                </form>
            </div>`;
        columnA.insertAdjacentHTML('beforeend', settingsPanelHTML);
        const realtimeToggle = document.getElementById('rtc-setting-realtime');
        const typingToggle = document.getElementById('rtc-setting-typing');
        const savedIndicator = document.getElementById('rtc-settings-saved');
        realtimeToggle.checked = SETTINGS.realtimeEnabled;
        typingToggle.checked = SETTINGS.typingEnabled;
        typingToggle.disabled = !SETTINGS.realtimeEnabled;
        const handleChange = () => {
            SETTINGS.realtimeEnabled = realtimeToggle.checked;
            SETTINGS.typingEnabled = typingToggle.checked;
            typingToggle.disabled = !realtimeToggle.checked;
            saveSettings(SETTINGS);
            savedIndicator.style.opacity = '1';
            setTimeout(() => { savedIndicator.style.opacity = '0'; }, 2000);
        };
        realtimeToggle.addEventListener('change', handleChange);
        typingToggle.addEventListener('change', handleChange);
    }

    function initializeTemplates() {
        const commentList = document.getElementById('comment_list');
        if (!commentList) return false;
        mainReplyTemplate = commentList.querySelector(".row_reply, .row.row_reply, .light_odd.row")?.cloneNode(true);
        if (mainReplyTemplate) {
            subReplyTemplate = mainReplyTemplate.querySelector(".sub_reply_bg, .topic_sub_reply")?.cloneNode(true);
            if (subReplyTemplate?.matches('.topic_sub_reply')) {
                subReplyTemplate = subReplyTemplate.querySelector('.sub_reply_bg')?.cloneNode(true);
            }
        }
        return !!mainReplyTemplate;
    }

    function main() {
        SETTINGS = getSettings();
        if (window.location.pathname.includes('/settings/privacy')) {
            injectCSS();
            initializeSettingsPage();
            return;
        }
        pageInfo = detectPage();
        if (!pageInfo) return;
        if (!SETTINGS.realtimeEnabled) {
            console.log('[BGM-Push] Realtime feature is disabled in settings.');
            return;
        }
        const faviconLink = document.querySelector("link[rel~='icon']");
        originalFaviconURL = faviconLink ? faviconLink.href : '/img/favicon.ico';
        const userLink = document.querySelector('#new_comment .reply_author a');
        selfNickname = userLink ? userLink.textContent.trim() : (window.CHOBITS_USERNAME || `user_${selfUID}`);
        if (!initializeTemplates()) {
            console.warn('[BGM-Push] No reply templates found. Realtime features disabled.');
            return;
        }
        formhash = document.querySelector('input[name="formhash"]')?.value || '';
        injectCSS();
        initializeStatusIndicator();
        buildEmojiMap();
        createNotifier();
        createTypingIndicator();
        initializeInteractionListeners();
        connect();
    }

    main();
})();