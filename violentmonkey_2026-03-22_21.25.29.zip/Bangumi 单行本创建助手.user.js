// ==UserScript==
// @name         Bangumi 单行本创建助手
// @namespace    https://bgm.tv/
// @version      1.3.2
// @description  在Bangumi小说和漫画条目页添加"新条目"按钮，方便复制创建相似条目，并且实现自动填充内容
// @author       Bios
// @include      /^https?:\/\/((bgm|bangumi)\.tv|chii\.in)\/(new_)?subject\/.*/
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_deleteValue
// @grant        GM_xmlhttpRequest
// @run-at       document-end
// @license      MIT
// ==/UserScript==

(function() {
    'use strict';

    const path = location.pathname;

    if (!(/^\/subject\/\d+$/.test(path) || /^\/new_subject\/1$/.test(path))) return;

    const styles = {
        // 添加全局样式
        addGlobalStyles() {
            if (document.querySelector('#bgm-helper-styles')) return;

            const styleSheet = document.createElement('style');
            styleSheet.id = 'bgm-helper-styles';
            styleSheet.textContent = `

                /* 克隆按钮样式 */
                #clone-entry-button {
                    transition: all 0.3s ease !important;
                    position: relative !important;
                }

                #clone-entry-button:hover {
                    background-color: color-mix(in srgb, #F09199 90%, black) !important;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.15) !important;
                }

                /* 通知区域样式改进 */
                #bgm-notification-area {
                    transition: all 0.3s ease !important;
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
                    font-size: 14px !important;
                    font-weight: 500 !important;
                }
            `;

            document.head.appendChild(styleSheet);
            log("已添加全局样式");
        }
    };

    // 调试日志函数
    function log(message) {
        console.log(`[BGM助手] ${message}`);
    }

    // 通知系统
    const notification = {
        // 添加通知区域
        addArea() {
            if (document.querySelector('#bgm-notification-area')) return;

            const notificationArea = document.createElement('div');
            notificationArea.id = 'bgm-notification-area';
            notificationArea.style.position = 'fixed';
            notificationArea.style.top = '10px';
            notificationArea.style.right = '10px';
            notificationArea.style.padding = '8px 15px';
            notificationArea.style.backgroundColor = '#369CF8';
            notificationArea.style.color = 'white';
            notificationArea.style.borderRadius = '5px';
            notificationArea.style.zIndex = '9999';
            notificationArea.style.display = 'none';
            notificationArea.style.boxShadow = '0 2px 5px rgba(0,0,0,0.2)';

            document.body.appendChild(notificationArea);
        },

        // 显示通知
        show(message, isError = false) {
            this.addArea();

            const notificationArea = document.querySelector('#bgm-notification-area');
            notificationArea.textContent = message;
            notificationArea.style.backgroundColor = isError ? '#FF5151' : '#369CF8';
            notificationArea.style.display = 'block';

            // 3秒后隐藏通知
            setTimeout(() => {
                notificationArea.style.display = 'none';
            }, 3000);

            // 如果支持GM通知，也显示一个
            if (typeof GM_notification !== 'undefined') {
                GM_notification({
                    title: 'Bangumi 条目创建助手',
                    text: message,
                    timeout: 3000
                });
            }

            // 同时在控制台输出
            log(message);
        }
    };

    // 数据存储系统
    const storage = {
        // 保存数据
        save(key, value) {
            if (typeof GM_setValue !== 'undefined') {
                GM_setValue(key, value);
                log(`使用GM_setValue保存数据: ${key}`);
                return true;
            } else if (typeof localStorage !== 'undefined') {
                try {
                    localStorage.setItem(key, value);
                    log(`使用localStorage保存数据: ${key}`);
                    return true;
                } catch (e) {
                    log(`localStorage保存失败: ${e.message}`);
                    return false;
                }
            }
            return false;
        },

        // 获取数据
        get(key) {
            if (typeof GM_getValue !== 'undefined') {
                const value = GM_getValue(key);
                log(`使用GM_getValue获取数据: ${key}=${value ? '有数据' : '无数据'}`);
                return value;
            } else if (typeof localStorage !== 'undefined') {
                try {
                    const value = localStorage.getItem(key);
                    log(`使用localStorage获取数据: ${key}=${value ? '有数据' : '无数据'}`);
                    return value;
                } catch (e) {
                    log(`localStorage获取失败: ${e.message}`);
                    return null;
                }
            }
            return null;
        },

        // 删除数据
        remove(key) {
            if (typeof GM_deleteValue !== 'undefined') {
                GM_deleteValue(key);
                log(`使用GM_deleteValue删除数据: ${key}`);
            } else if (typeof localStorage !== 'undefined') {
                try {
                    localStorage.removeItem(key);
                    log(`使用localStorage删除数据: ${key}`);
                } catch (e) {
                    log(`localStorage删除失败: ${e.message}`);
                }
            }
        },

        // 根据前缀查找最新的存储项
        findLatestByPrefix(prefix) {
            if (typeof localStorage === 'undefined') return null;

            const foundKeys = [];
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                if (key.startsWith(prefix)) {
                    foundKeys.push(key);
                }
            }

            if (foundKeys.length === 0) return null;

            foundKeys.sort();
            return foundKeys[foundKeys.length - 1].split('_').slice(0, -1).join('_');
        }
    };

    // 网络请求系统
    const network = {
        // 发起请求，自动选择合适的方法
        request(url, onSuccess, onError) {
            log(`发起请求: ${url}`);

            // 尝试使用fetch
            if (window.fetch) {
                fetch(url)
                    .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP状态码: ${response.status}`);
                    }
                    return response.text();
                })
                    .then(html => onSuccess(html))
                    .catch(e => {
                    log(`Fetch错误: ${e.message}`);
                    // fetch失败，尝试使用GM_xmlhttpRequest
                    if (typeof GM_xmlhttpRequest !== 'undefined') {
                        this.requestWithGM(url, onSuccess, onError);
                    } else if (onError) {
                        onError(`请求失败: ${e.message}`);
                    }
                });
            }
            // 否则尝试使用GM_xmlhttpRequest
            else if (typeof GM_xmlhttpRequest !== 'undefined') {
                this.requestWithGM(url, onSuccess, onError);
            }
            // 都不支持
            else if (onError) {
                onError("浏览器不支持所需的请求方法");
            }
        },

        // 使用GM_xmlhttpRequest请求
        requestWithGM(url, onSuccess, onError) {
            log(`使用GM_xmlhttpRequest请求: ${url}`);

            GM_xmlhttpRequest({
                method: "GET",
                url: url.startsWith('//') ? window.location.protocol + url : url,
                timeout: 10000, // 10秒超时
                onload: function(response) {
                    if (response.status !== 200) {
                        if (onError) onError(`请求失败，状态码: ${response.status}`);
                        return;
                    }
                    onSuccess(response.responseText);
                },
                onerror: function(error) {
                    if (onError) onError("网络请求失败，请检查网络连接");
                    log("请求失败", error);
                },
                ontimeout: function() {
                    if (onError) onError("请求超时，请稍后重试");
                }
            });
        }
    };

    // 条目处理系统
    const entryHandler = {
        // 识别Infobox类型
        identifyType(content) {
            if (!content) return "Unknown";

            if (content.includes("Infobox animanga/Novel")) {
                return "Novel";
            } else if (content.includes("Infobox animanga/Manga")) {
                return "Manga";
            }

            return "Unknown";
        },

        // 存储条目数据
        storeEntryData(content, type, title, sourceId) {
            const keyPrefix = `bgm_infobox_${sourceId}`;

            const savedContent = storage.save(`${keyPrefix}_content`, content);
            const savedType = storage.save(`${keyPrefix}_type`, type);
            storage.save(`${keyPrefix}_title`, title);

            return savedContent && savedType;
        },

        // 解析编辑页内容
        parseEditPage(html, title, sourceId) {
            try {
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, "text/html");

                // 检查是否需要登录
                const loginForm = doc.querySelector('form[action="/FollowTheRabbit"]');
                if (loginForm) {
                    notification.show("获取失败，请先登录Bangumi", true);
                    return false;
                }

                const textarea = doc.querySelector('#subject_summary');
                if (!textarea) {
                    notification.show("未找到条目内容，可能没有编辑权限", true);
                    return false;
                }

                const content = textarea.value;
                if (!content) {
                    notification.show("条目内容为空", true);
                    return false;
                }

                // 识别条目类型
                const type = this.identifyType(content);
                if (type === "Unknown") {
                    notification.show("未识别 Infobox 类型（支持 Novel 或 Manga）", true);
                    return false;
                }

                // 存储数据
                if (!this.storeEntryData(content, type, title, sourceId)) {
                    notification.show("保存数据失败，请检查浏览器权限", true);
                    return false;
                }

                return true;
            } catch (e) {
                notification.show(`解析页面失败: ${e.message}`, true);
                console.error(e);
                return false;
            }
        },

        // 将原标题处理为新建条目标题
        processTitle(title) {
            if (!title) return "";

            const match = title.match(/\((\d+)\)$/);
            if (match) {
                const num = parseInt(match[1], 10) + 1;
                return title.replace(/\(\d+\)$/, `(${num})`);
            } else {
                return `${title} (1)`;
            }
        }
    };

    // 页面功能系统
    const pageFeatures = {
        // 在条目页添加"新条目"按钮
        addCreateButton() {
            const currentPath = location.pathname;
            const matchSubject = currentPath.match(/^\/subject\/(\d+)$/);
            if (!matchSubject) {
                log("当前页面不是条目页面，不添加按钮");
                return;
            }

            // 检查类型是否为"小说"或"漫画"
            const genreSmall = document.querySelector('small.grey');
            if (!genreSmall || !(genreSmall.textContent.trim() === '小说' || genreSmall.textContent.trim() === '漫画')) {
                log(`条目类型不是小说或漫画: ${genreSmall ? genreSmall.textContent.trim() : '未找到'}`);
                return;
            }

            // 查找导航栏并避免重复添加
            const nav = document.querySelector(".subjectNav .navTabs, .navTabs");
            if (!nav || nav.querySelector(".create-button")) {
                log(nav ? "按钮已存在，不重复添加" : "未找到导航栏");
                return;
            }

            // 准备通知区域
            notification.addArea();

            // 创建并添加按钮
            const createLi = document.createElement("li");
            createLi.className = "create-button";
            const subjectId = matchSubject[1];
            createLi.innerHTML = `<a href="javascript:void(0);" class="create-button-link">新条目</a>`;

            // 按钮点击事件
            createLi.querySelector("a").addEventListener("click", () => {
                this.handleCreateButtonClick(subjectId);
            });

            nav.appendChild(createLi);
            log("成功添加新条目按钮");
        },

        // 处理创建按钮点击
        handleCreateButtonClick(subjectId) {
            notification.show("正在获取条目内容...");

            const currentHost = window.location.hostname;
            const editUrl = `//${currentHost}/subject/${subjectId}/edit`;
            const title = document.querySelector('h1 a[property="v:itemreviewed"]')?.textContent?.trim() ||
                  document.querySelector('h1.nameSingle a')?.textContent?.trim() || '';

            // 唯一标识符
            const uniqueId = Date.now().toString();

            // 发起请求获取编辑页内容
            network.request(
                editUrl,
                (html) => {
                    // 成功处理编辑页内容
                    if (entryHandler.parseEditPage(html, title, uniqueId)) {
                        notification.show("条目内容获取成功，正在打开创建页面...");
                        window.open(`//${currentHost}/new_subject/1?source=${uniqueId}`, "_blank");
                    }
                },
                (errorMsg) => {
                    notification.show(errorMsg, true);
                }
            );
        },

        // 添加"复制创建"按钮到新建条目页面
        addCloneButton() {
            if (!location.pathname.includes("/new_subject/1")) {
                log("当前不是新建条目页面，不添加克隆按钮");
                return;
            }

            // 查找标题并检查
            const titleHeader = document.querySelector('h1');
            if (!titleHeader || !titleHeader.textContent.includes('添加')) {
                log(`标题元素不符合条件: ${titleHeader ? titleHeader.textContent : '未找到'}`);
                return;
            }

            // 避免重复添加
            if (document.querySelector('#clone-entry-button')) {
                log("克隆按钮已存在，不重复添加");
                return;
            }

            // 准备通知区域
            notification.addArea();

            // 创建按钮
            const cloneButton = document.createElement('button');
            cloneButton.id = 'clone-entry-button';
            cloneButton.textContent = '新条目';
            cloneButton.style.cssText = 'background-color:#F09199; color:white; border:none; padding:5px 10px; border-radius:4px; margin-left:10px; cursor:pointer; font-weight:bold; text-align:center;';

            // 添加到页面
            titleHeader.appendChild(cloneButton);
            log("成功添加克隆按钮");

            // 添加点击事件
            cloneButton.addEventListener('click', () => {
                this.handleCloneButtonClick();
            });
        },

        // 处理克隆按钮点击
        handleCloneButtonClick() {
            // 尝试切换到Wiki模式
            const wikiModeLink = document.querySelector('a[onclick="NormaltoWCODE()"]');
            if (wikiModeLink) {
                wikiModeLink.click();
                log("已自动切换到Wiki模式");
            }

            // 获取表单内容
            const infobox = document.querySelector("#subject_infobox");
            const titleInput = document.querySelector('input[name="subject_title"]');

            if (!infobox || !titleInput) {
                notification.show("无法获取表单内容，请确保已切换到Wiki模式", true);
                return;
            }

            const content = infobox.value;
            const title = titleInput.value;

            if (!content) {
                notification.show("Infobox内容为空", true);
                return;
            }

            // 识别类型
            const type = entryHandler.identifyType(content);
            if (type === "Unknown") {
                notification.show("未识别 Infobox 类型（支持 Novel 或 Manga）", true);
                return;
            }

            // 生成唯一ID
            const cloneId = 'clone_' + Date.now();

            // 存储数据
            if (!entryHandler.storeEntryData(content, type, title, cloneId)) {
                notification.show("保存数据失败，请检查浏览器权限", true);
                return;
            }

            notification.show("已复制当前页面条目内容，正在打开新建页面...");

            // 打开新页面
            const currentHost = window.location.hostname;
            window.open(`//${currentHost}/new_subject/1?source=${cloneId}`, "_blank");
        },

        // 自动填充表单
        fillNewSubjectForm() {
            // 获取URL参数
            const sourceId = new URL(window.location.href).searchParams.get("source");
            if (!sourceId) {
                log("没有找到source参数，不执行填充");
                return;
            }

            log(`检测到source参数: ${sourceId}`);
            notification.addArea();

            // 构建键名前缀并获取数据
            const keyPrefix = `bgm_infobox_${sourceId}`;
            let content = storage.get(`${keyPrefix}_content`);
            let type = storage.get(`${keyPrefix}_type`);
            let title = storage.get(`${keyPrefix}_title`);

            // 如果找不到数据，尝试使用旧版键名
            if (!content || !type) {
                log(`未找到数据: ${keyPrefix}`);

                // 尝试旧版键名
                const oldKeyPrefix = `infobox_${sourceId}`;
                const oldContent = storage.get(`${oldKeyPrefix}_content`);
                const oldType = storage.get(`${oldKeyPrefix}_type`);
                const oldTitle = storage.get(`${oldKeyPrefix}_title`);

                if (oldContent && oldType) {
                    log(`找到旧版数据: ${oldKeyPrefix}`);
                    content = oldContent;
                    type = oldType;
                    title = oldTitle;
                } else {
                    // 尝试找到最新的相关键
                    const latestKeyBase = storage.findLatestByPrefix('bgm_infobox_') || storage.findLatestByPrefix('infobox_');

                    if (latestKeyBase) {
                        log(`尝试使用最近的键前缀: ${latestKeyBase}`);
                        content = storage.get(`${latestKeyBase}_content`);
                        type = storage.get(`${latestKeyBase}_type`);
                        title = storage.get(`${latestKeyBase}_title`);
                    }
                }

                if (!content || !type) {
                    notification.show("未找到条目内容，请重试", true);
                    return;
                }
            }

            // 开始填充表单
            this.performFormFill(content, type, title, keyPrefix);
        },

        // 执行表单填充
        performFormFill(content, type, title, keyPrefix) {
            // 定义类型映射
            const typeMap = {
                "Novel": { id: "cat_novel", tpl: "Novel" },
                "Manga": { id: "cat_comic", tpl: "Manga" }
            };

            const category = typeMap[type];
            if (!category) {
                log(`未知条目类型: ${type}`);
                return;
            }

            notification.show("正在填充条目信息...");
            log(`准备填充 ${type} 类型的条目，标题: ${title || '无标题'}`);

            // 等待表单加载
            this.waitForForm(category, content, title, keyPrefix);
        },

        // 等待表单加载
        waitForForm(category, content, title, keyPrefix) {
            // 检查表单是否加载完成
            const checkForm = () => {
                const infoboxInput = document.querySelector("#subject_infobox");
                const titleInput = document.querySelector('input[name="subject_title"]');
                const typeRadio = document.getElementById(category.id);
                return infoboxInput && titleInput && typeRadio;
            };

            // 如果表单已加载，立即填充
            if (checkForm()) {
                this.doFillForm(category, content, title, keyPrefix);
                return;
            }

            // 否则等待表单加载
            log("等待表单加载...");
            let attempts = 0;
            const maxAttempts = 30; // 最多等待6秒

            const waitInterval = setInterval(() => {
                attempts++;
                if (checkForm()) {
                    clearInterval(waitInterval);
                    log("表单已加载，开始填充");
                    this.doFillForm(category, content, title, keyPrefix);
                    return;
                }

                if (attempts >= maxAttempts) {
                    clearInterval(waitInterval);
                    log("表单加载超时");
                    notification.show("表单加载超时，请手动填写", true);
                }
            }, 200);
        },

        // 实际执行表单填充
        doFillForm(category, content, title, keyPrefix) {
            try {
                // 选择分类
                const typeRadio = document.getElementById(category.id);
                if (typeRadio) {
                    typeRadio.click();
                    log(`已选择类型: ${category.tpl}`);
                } else {
                    log(`未找到类型选择框: ${category.id}`);
                }

                // 等待分类选择完成后填充表单
                setTimeout(() => {
                    try {
                        // 填充内容
                        const infobox = document.querySelector("#subject_infobox");
                        if (infobox) {
                            infobox.value = content;
                            log("已填充Infobox内容");
                            infobox.dispatchEvent(new Event('change', { bubbles: true }));
                        }

                        // 填充标题
                        const titleInput = document.querySelector('input[name="subject_title"]');
                        if (titleInput && title) {
                            const newTitle = entryHandler.processTitle(title);
                            titleInput.value = newTitle;
                            log(`已填充标题: ${newTitle}`);
                            titleInput.dispatchEvent(new Event('change', { bubbles: true }));
                        }

                        // 根据需要切换模式
                        const currentMode = document.querySelector('#header_infobox');
                        const wikiModeLink = document.querySelector('a[onclick*="NormaltoWCODE"]');
                        const simpleModeLink = document.querySelector('a[onclick*="WCODEtoNormal"]');
                        const isInWikiMode = currentMode && currentMode.textContent.includes('WCODE');

                        if (!isInWikiMode && wikiModeLink) {
                            wikiModeLink.click();
                            log("已切换到wiki模式");
                        } else if (isInWikiMode && simpleModeLink) {
                            simpleModeLink.click();
                            log("已切换到入门模式");
                        }

                        // 显示成功通知
                        notification.show("条目信息填充完成");

                        // 清理临时数据
                        if (keyPrefix) {
                            storage.remove(`${keyPrefix}_content`);
                            storage.remove(`${keyPrefix}_type`);
                            storage.remove(`${keyPrefix}_title`);
                            log("已清理临时数据");
                        }
                    } catch (e) {
                        notification.show(`填充表单时出错: ${e.message}`, true);
                        console.error(e);
                    }
                }, 500);
            } catch (e) {
                notification.show(`选择分类时出错: ${e.message}`, true);
                console.error(e);
            }
        }
    };

    // 初始化
    function init() {
        log("Bangumi条目创建助手初始化中...");

        // 首先添加全局样式
        styles.addGlobalStyles();

        // 若当前页面是条目页面，添加"新条目"按钮
        if (location.pathname.match(/^\/subject\/\d+$/)) {
            log("检测到条目页面");
            pageFeatures.addCreateButton();
        }

        // 若当前页面是创建条目页，添加功能
        if (location.pathname.includes("/new_subject/1")) {
            log("检测到新建条目页面");
            pageFeatures.addCloneButton();

            // 如果有source参数，则填充表单
            if (location.search.includes("source=")) {
                log("检测到source参数，准备填充表单");
                setTimeout(function() {
                    pageFeatures.fillNewSubjectForm();
                }, 500);
            }
        }

        log("初始化完成");
    }

    // 页面加载完成后执行初始化
    window.addEventListener("load", init);
    // 也可以在DOM加载完成后就执行，提高响应速度
    if (document.readyState === "interactive" || document.readyState === "complete") {
        init();
    } else {
        document.addEventListener("DOMContentLoaded", init);
    }
})();