// ==UserScript==
// @name         frostmoon → bangumi 漫画建条（完整版）
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  从frostmoon漫画页提取信息到Bangumi，含复制封面、summary、标题、作者、价格、ISBN
// @match        https://frostmoon.sakura.ne.jp/collection/comics/*
// @match        https://bgm.tv/new_subject/1
// @match        https://bangumi.tv/new_subject/1
// @match        https://chii.in/new_subject/1
// @grant        GM_xmlhttpRequest
// @grant        GM_openInTab
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_deleteValue
// @grant        GM_setClipboard
// @license      MIT
// ==/UserScript==

(function() {
    'use strict';

    // 全角数字转半角
    function full2half(str) {
        if (!str) return '';
        let res = '';
        for (let c of str) {
            const code = c.charCodeAt(0);
            // 1. 全角数字 (０-９ → 0-9)
            if (code >= 65296 && code <= 65305) {
                res += String.fromCharCode(code - 65248);
            }
            // 2. 全角大写字母 (Ａ-Ｚ → A-Z)
            else if (code >= 65313 && code <= 65338) {
                res += String.fromCharCode(code - 65248);
            }
            // 3. 全角小写字母 (ａ-ｚ → a-z)
            else if (code >= 65345 && code <= 65370) {
                res += String.fromCharCode(code - 65248);
            }
            // 4. 其他字符（全角空格/符号等）保持原样
            else {
                res += c;
            }
        }
        return res;
    }

    // 图片转 DataURL
    function imageUrlToDataUrl(url, callback) {
        if (!url) {
            callback('');
            return;
        }
        GM_xmlhttpRequest({
            method: 'GET',
            url: url,
            responseType: 'arraybuffer',
            onload: function(response) {
                try {
                    let mimeType = 'image/jpeg';
                    const base64 = btoa(
                        new Uint8Array(response.response).reduce(
                            (data, byte) => data + String.fromCharCode(byte), ''
                        )
                    );
                    callback(`data:${mimeType};base64,${base64}`);
                } catch (e) {
                    callback('');
                }
            },
            onerror: function() {
                callback('');
            }
        });
    }

    // ISBN10 → ISBN13
    function isbn10ToIsbn13(isbn10) {
        const cleaned = isbn10.replace(/[^0-9Xx]/g, '');
        if (cleaned.length !== 10) return null;
        let isbn13 = '978' + cleaned.substring(0, 9);
        let sum = 0;
        for (let i = 0; i < 12; i++) {
            const digit = parseInt(isbn13.charAt(i), 10);
            sum += (i % 2 === 0) ? digit * 1 : digit * 3;
        }
        const checksum = (10 - (sum % 10)) % 10;
        return isbn13 + checksum;
    }

    // 处理 ISBN（去横杠 + 转13位）
    function processIsbn(isbn) {
        if (!isbn) return '';
        const clean = isbn.replace(/-/g, '');
        if (clean.length === 10) return isbn10ToIsbn13(clean) || clean;
        if (clean.length === 13) return clean;
        return clean;
    }

    // 日期格式化
    function processDate(text) {
        if (!text) return '';
        const s = text.replace(/年|月|日/g, '-').replace(/-$/, '');
        const parts = s.split('-').map(p => p.trim()).filter(Boolean);
        if (parts.length === 3) {
            return `${parts[0]}-${parts[1].padStart(2, '0')}-${parts[2].padStart(2, '0')}`;
        }
        return text.trim();
    }

    // 按 th 文字获取 td 内容
    function getTextByTh(thText) {
        const trs = document.querySelectorAll('table tr');
        for (const tr of trs) {
            const th = tr.querySelector('th');
            if (th && th.textContent.trim() === thText) {
                const td = tr.querySelector('td');
                return td ? td.textContent.trim() : '';
            }
        }
        return '';
    }

    // 获取作品介绍 summary
    function getSummary() {
        const items = document.querySelectorAll('.item');
        for (const item of items) {
            const h2 = item.querySelector('h2');
            if (h2 && h2.textContent.trim() === '作品かいせつ') {
                const next = item.nextElementSibling;
                if (next && next.classList.contains('data')) {
                    return next.textContent.trim();
                }
            }
        }
        return '';
    }

    // 复制封面图到剪贴板
    function copyCoverToClipboard() {
        const img = document.querySelector('.cover img');
        if (!img) {
            alert('未找到封面');
            return;
        }
        const url = img.src.startsWith('http') ? img.src : location.origin + img.src;
        GM_xmlhttpRequest({
            method: 'GET',
            url: url,
            responseType: 'blob',
            onload: function(r) {
                try {
                    const item = new ClipboardItem({ [r.response.type]: r.response });
                    navigator.clipboard.write([item]).then(() => {
                        alert('封面已复制到剪贴板');
                    });
                } catch (e) {
                    alert('复制失败');
                }
            }
        });
    }

    // ==================== 漫画页面 ====================
    if (location.host === 'frostmoon.sakura.ne.jp') {
        // 添加按钮
        function addButtons() {
            if (document.querySelector('#fm-add-btn')) return;

            const container = document.createElement('div');
            container.style.margin = '10px 0';

            const btn1 = document.createElement('a');
            btn1.id = 'fm-add-btn';
            btn1.textContent = '→ 添加到 bangumi';
            btn1.style.marginRight = '12px';
            btn1.style.cursor = 'pointer';
            btn1.style.color = '#0066cc';

            const btn2 = document.createElement('a');
            btn2.textContent = '📷 复制封面';
            btn2.style.cursor = 'pointer';
            btn2.style.color = '#0066cc';

            btn2.addEventListener('click', () => copyCoverToClipboard());

            btn1.addEventListener('click', () => {
                const ken = getTextByTh('巻');
                const title = `${getTextByTh('タイトル')}${ken ? ` (${ken})` : ''}`;
                const author = getTextByTh('作者').replace(/<[^>]+>/g, '').trim();
                const priceText = getTextByTh('定価');
                const isbn13 = getTextByTh('ISBN-13');
                const isbn10 = getTextByTh('ISBN-10');
                const firstDate = getTextByTh('初版');
                const summary = getSummary();

                const price = `${full2half(priceText).replace(/(\d+)円/g, 'JP¥$1')}`;
                const isbn = processIsbn(isbn13 || isbn10);
                const date = processDate(firstDate);
                const cover = document.querySelector('.cover img')?.src || '';
                const fullCover = cover.startsWith('http') ? cover : location.origin + cover;

                imageUrlToDataUrl(fullCover, dataUrl => {
                    GM_setValue('frostmoonData', JSON.stringify({
                        title, author, price, isbn, date, summary, dataUrl
                    }));
                    GM_openInTab('https://bgm.tv/new_subject/1', { active: true });
                });
            });

            container.append(btn1, btn2);
            document.querySelector('.des')?.prepend(container);
        }

        addButtons();
        new MutationObserver(addButtons).observe(document.body, { childList: true, subtree: true });
    }

    // ==================== BGM 新建条目页 ====================
    else if (location.pathname === '/new_subject/1') {
        function wait(sel, cb) {
            const e = document.querySelector(sel);
            if (e) return cb(e);
            const obs = new MutationObserver(() => {
                const el = document.querySelector(sel);
                if (el) { obs.disconnect(); cb(el); }
            });
            obs.observe(document.body, { childList: true, subtree: true });
        }

        const data = GM_getValue('frostmoonData');
        if (!data) return;

        const obj = JSON.parse(data);
        GM_deleteValue('frostmoonData');

        // 填标题
        wait('input[name="subject_title"]', el => {
            el.value = full2half(obj.title);
        });

        // 填 infobox
        wait('textarea', el => {
            el.value = `{{Infobox animanga/Book
|中文名=
|别名=
|作者= ${obj.author}
|作画=
|脚本=
|原作=
|出版社= 白泉社
|书系= 花とゆめコミックス
|价格= ${obj.price}
|发售日= ${obj.date}
|ISBN= ${obj.isbn}
}}`;
        });

        if (obj.summary) {
            wait('#subject_summary', el => el.value = obj.summary);
        }

        // 封面预览
        if (obj.dataUrl) {
            wait('img.preview', img => {
                img.src = obj.dataUrl;
            });
        }

        // 选漫画分类
        wait('#cat_comic', c => c.click());
    }
})();
