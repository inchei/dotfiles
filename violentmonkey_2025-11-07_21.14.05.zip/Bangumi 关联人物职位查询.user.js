// ==UserScript==
// @name         Bangumi 关联人物职位查询
// @namespace    https://bangumi.tv
// @version      3.4
// @description  在关联人物编辑页面快速查看人物最近参与的职位信息，查询后自动隐藏按钮
// @author       wqahfaoihgfpo
// @match        https://bgm.tv/subject/*/add_related/person
// @match        https://bangumi.tv/subject/*/add_related/person
// @run-at       document-idle
// @license      MIT
// @downloadURL https://update.greasyfork.org/scripts/539119/Bangumi%20%E5%85%B3%E8%81%94%E4%BA%BA%E7%89%A9%E8%81%8C%E4%BD%8D%E6%9F%A5%E8%AF%A2.user.js
// @updateURL https://update.greasyfork.org/scripts/539119/Bangumi%20%E5%85%B3%E8%81%94%E4%BA%BA%E7%89%A9%E8%81%8C%E4%BD%8D%E6%9F%A5%E8%AF%A2.meta.js
// ==/UserScript==

(function() {
    'use strict';

    // 添加样式
    const style = document.createElement('style');
    style.textContent = `
        .position-helper-container {
            margin: 10px 0;
            display: flex;
            justify-content: flex-start;
        }
        .position-btn {
            padding: 5px 15px;
            font-size: 12px;
            background-color: #f5f5f5;
            color: #333;
            border: 1px solid #ddd;
            border-radius: 3px;
            cursor: pointer;
            transition: all 0.3s;
            font-family: inherit;
            box-sizing: border-box;
            height: 28px;
            line-height: 16px;
        }
        .position-btn.fetching {
            background-color: #f5f5f5;
            color: #999;
            border-color: #ddd;
        }
        .position-btn.fetching:hover {
            background-color: #ffebee;
            color: #c62828;
            border-color: #ffcdd2;
        }
        /* 单个人物查询按钮样式 */
        .position-single-btn {
            padding: 2px 6px;
            font-size: 11px;
            background-color: #f0f0f0;
            color: #666;
            border: 1px solid #ddd;
            border-radius: 3px;
            cursor: pointer;
            transition: all 0.2s;
            margin-left: 6px;
            height: 20px;
            line-height: 14px;
            flex-shrink: 0;
        }
        .position-single-btn:hover {
            background-color: #e6f2ff;
            color: #0066cc;
            border-color: #b8d9ff;
        }
        .position-single-btn.fetching {
            background-color: #fff8e1;
            color: #ff8f00;
            border-color: #ffe082;
            cursor: not-allowed;
        }
        .position-tags {
            display: flex;
            flex-wrap: nowrap;
            margin-left: 5px;
            vertical-align: middle;
            max-width: 70%;
            overflow: hidden;
            align-items: center;
        }
        .position-tag {
            flex: 0 0 auto;
            padding: 2px 6px;
            background-color: #e6f2ff;
            border-radius: 3px;
            color: #0066cc;
            font-size: 12px;
            margin-right: 5px;
            margin-bottom: 3px;
            border: 1px solid #b8d9ff;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .position-tag.unmatched {
            background-color: #f0f0f0;
            color: #666;
            border-color: #ddd;
        }
        .position-indicator {
            display: inline-block;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 12px;
            margin-left: 5px;
        }
        .position-indicator.error {
            background-color: #ffebee;
            color: #c62828;
            border: 1px solid #ffcdd2;
        }
        .position-indicator.loading {
            background-color: #fff8e1;
            color: #ff8f00;
            border: 1px solid #ffe082;
        }
        .matched-position {
            color: #0066cc;
            font-weight: bold;
        }
        .position-more {
            flex: 0 0 auto;
            padding: 2px 6px;
            background-color: #f0f0f0;
            border-radius: 3px;
            color: #666;
            font-size: 12px;
            margin-right: 5px;
            margin-bottom: 3px;
            border: 1px solid #ddd;
            cursor: pointer;
            white-space: nowrap;
        }
        .position-popup {
            position: absolute;
            background: white;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            z-index: 1000;
            max-height: 300px;
            overflow-y: auto;
            font-size: 12px;
            line-height: 1.5;
        }
        .position-popup ul {
            margin: 0;
            padding: 0;
            list-style: none;
        }
        .position-popup li {
            padding: 3px 0;
            border-bottom: 1px solid #eee;
        }
        .position-popup li:last-child {
            border-bottom: none;
        }
        .crtRelatedLeft li .title {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            position: relative;
        }
    `;
    document.head.appendChild(style);

    // 创建辅助容器
    function createHelperContainer() {
        const container = document.createElement('div');
        container.className = 'position-helper-container';
        container.innerHTML = `
            <button id="fetchPositions" class="position-btn inputBtn">获取职位</button>
        `;
        return container;
    }

    // 获取人物ID
    function getPersonId(link) {
        const match = link.href.match(/person\/(\d+)/);
        return match ? match[1] : null;
    }

    // 全局变量存储当前打开的弹出层
    let currentPopup = null;
    // 缓存已请求的人物职位数据
    const positionCache = new Map();

    // 关闭所有弹出层
    function closeAllPopups() {
        if (currentPopup) {
            currentPopup.remove();
            currentPopup = null;
        }
        document.removeEventListener('click', closeAllPopups);
    }

    // 显示职位详情弹出层
    function showPositionPopup(positions, targetElement) {
        closeAllPopups();

        const popup = document.createElement('div');
        popup.className = 'position-popup';

        const list = document.createElement('ul');
        positions.forEach(pos => {
            const item = document.createElement('li');
            item.textContent = `${pos.name} (${pos.count}次)`;
            list.appendChild(item);
        });

        popup.appendChild(list);

        // 定位弹出层
        const rect = targetElement.getBoundingClientRect();
        popup.style.left = `${rect.left}px`;
        popup.style.top = `${rect.bottom + 5}px`;

        document.body.appendChild(popup);
        currentPopup = popup;

        // 添加全局点击事件关闭弹出层
        setTimeout(() => {
            document.addEventListener('click', closeAllPopups);
        }, 100);

        // 阻止弹出层内部点击事件冒泡
        popup.addEventListener('click', e => {
            e.stopPropagation();
        });
    }

    // 移除单个人物的查询按钮
    function removeSingleButton(titleElement) {
        const singleBtn = titleElement.querySelector('.position-single-btn');
        if (singleBtn) {
            singleBtn.remove();
        }
    }

    // 获取人物职位信息
    function fetchPersonPosition(personId, titleElement, singleBtn = null) {
        return new Promise((resolve) => {
            // 检查是否已有职位信息元素
            let positionSpan = titleElement.querySelector('.position-indicator');
            if (!positionSpan) {
                positionSpan = document.createElement('span');
                positionSpan.className = 'position-indicator loading';
                titleElement.appendChild(positionSpan);
            }

            // 检查缓存
            if (positionCache.has(personId)) {
                const positions = positionCache.get(personId);
                processPositionData(positions, titleElement, singleBtn);
                resolve(positions);
                return;
            }

            // 设置加载状态
            positionSpan.textContent = '加载中...';
            positionSpan.className = 'position-indicator loading';

            // 如果有单独按钮，也设置其加载状态
            if (singleBtn) {
                singleBtn.classList.add('fetching');
                singleBtn.textContent = '查询中';
            }

            // 使用fetch请求人物作品页面
            fetch(`https://bgm.tv/person/${personId}/works`, {
                method: 'GET',
                credentials: 'same-origin',
                headers: {
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.text();
            })
            .then(html => {
                try {
                    const tempDiv = document.createElement('div');
                    tempDiv.innerHTML = html;

                    const positions = parsePositionGroups(tempDiv);
                    positionCache.set(personId, positions);

                    if (positions.length > 0) {
                        processPositionData(positions, titleElement, singleBtn);
                    } else {
                        positionSpan.textContent = '无职位信息';
                        positionSpan.className = 'position-indicator error';
                        // 移除按钮
                        removeSingleButton(titleElement);
                    }

                    resolve(positions);
                } catch (e) {
                    console.error("解析失败:", e);
                    positionSpan.textContent = '解析失败';
                    positionSpan.className = 'position-indicator error';
                    // 移除按钮
                    removeSingleButton(titleElement);

                    resolve(null);
                }
            })
            .catch(error => {
                console.error("请求失败:", error);
                positionSpan.textContent = '请求失败';
                positionSpan.className = 'position-indicator error';
                // 移除按钮
                removeSingleButton(titleElement);

                resolve(null);
            });
        });
    }

    // 处理职位数据并更新UI
    function processPositionData(positions, titleElement, singleBtn = null) {
        // 移除加载指示器
        const positionSpan = titleElement.querySelector('.position-indicator');
        if (positionSpan) positionSpan.remove();

        // 创建职位标签容器
        const tagsContainer = document.createElement('div');
        tagsContainer.className = 'position-tags';
        titleElement.appendChild(tagsContainer);

        // 获取当前条目的职位备选框
        const liElement = titleElement.closest('li');
        const selectElement = liElement.querySelector('select[name^="infoArr"]');

        // 获取备选框中的所有职位选项的纯文本
        const positionOptions = Array.from(selectElement.options).map(opt => {
            return opt.text.split('/')[0].trim();
        });

        // 分离匹配和非匹配职位
        const matchedPositions = [];
        const unmatchedPositions = [];

        positions.forEach(pos => {
            if (positionOptions.includes(pos.name)) {
                matchedPositions.push(pos);
            } else {
                unmatchedPositions.push(pos);
            }
        });

        // 排序
        matchedPositions.sort((a, b) => b.count - a.count);
        unmatchedPositions.sort((a, b) => b.count - a.count);

        // 合并职位列表
        const allPositions = [...matchedPositions, ...unmatchedPositions];

        // 确定要显示的职位数量
        let displayCount = Math.min(2, allPositions.length);

        // 只取前N个职位
        const displayPositions = allPositions.slice(0, displayCount);

        // 使用文档片段优化DOM操作
        const fragment = document.createDocumentFragment();

        // 添加职位标签
        displayPositions.forEach(pos => {
            const tag = document.createElement('span');
            tag.className = 'position-tag';
            tag.title = pos.name;

            if (!positionOptions.includes(pos.name)) {
                tag.className += ' unmatched';
            }

            // 限制显示长度
            let displayText = pos.name;
            if (displayText.length > 20) {
                displayText = displayText.substring(0, 18) + '...';
            }

            tag.textContent = displayText;
            fragment.appendChild(tag);
        });

        // 如果有更多职位，添加"更多"指示器
        if (allPositions.length > displayCount) {
            const moreTag = document.createElement('span');
            moreTag.className = 'position-more';
            moreTag.textContent = `+${allPositions.length - displayCount}更多`;

            moreTag.addEventListener('click', function(e) {
                e.stopPropagation();
                showPositionPopup(allPositions, moreTag);
            });

            fragment.appendChild(moreTag);
        }

        tagsContainer.appendChild(fragment);

        // 更新备选框顺序
        updatePositionSelect(selectElement, positions, positionOptions);

        // 查完职位后移除单独查询按钮（无论是否有单独按钮都执行）
        removeSingleButton(titleElement);
    }

    // 解析职位组信息
    function parsePositionGroups(container) {
        const positions = [];

        const workItems = container.querySelectorAll('#browserItemList > li');
        const positionCounts = {};

        for (const item of workItems) {
            const positionTags = item.querySelectorAll('.badge_job');
            for (const tag of positionTags) {
                const positionName = tag.textContent.trim();
                positionCounts[positionName] = (positionCounts[positionName] || 0) + 1;
            }
        }

        // 转换为数组并按次数排序
        for (const [name, count] of Object.entries(positionCounts)) {
            positions.push({ name, count });
        }

        positions.sort((a, b) => b.count - a.count);

        return positions;
    }

    // 更新职位下拉框顺序
    function updatePositionSelect(selectElement, positions, positionOptions) {
        const selectedValue = selectElement.value;
        const options = Array.from(selectElement.options);

        const matchedOptions = [];
        const optionMap = new Map();

        options.forEach(opt => {
            const pureText = opt.text.split('/')[0].trim();
            optionMap.set(pureText, opt);
        });

        positions.forEach(pos => {
            if (positionOptions.includes(pos.name) && optionMap.has(pos.name)) {
                matchedOptions.push({
                    option: optionMap.get(pos.name),
                    count: pos.count
                });
            }
        });

        matchedOptions.sort((a, b) => b.count - a.count);

        const newOptions = [];

        if (selectedValue) {
            const selectedOption = options.find(opt => opt.value === selectedValue);
            if (selectedOption) {
                const pureText = selectedOption.text.split('/')[0].trim();
                const isMatched = matchedOptions.some(m => m.option.value === selectedOption.value);

                const option = document.createElement('option');
                option.value = selectedOption.value;
                option.text = selectedOption.text;
                if (isMatched) {
                    option.className = 'matched-position';
                }
                newOptions.push(option);
            }
        }

        matchedOptions.forEach(item => {
            if (!selectedValue || item.option.value !== selectedValue) {
                const option = document.createElement('option');
                option.value = item.option.value;
                option.text = item.option.text;
                option.className = 'matched-position';
                newOptions.push(option);
            }
        });

        options.forEach(opt => {
            const pureText = opt.text.split('/')[0].trim();
            if (!matchedOptions.some(m => m.option.value === opt.value) &&
                (!selectedValue || opt.value !== selectedValue)) {
                const option = document.createElement('option');
                option.value = opt.value;
                option.text = opt.text;
                newOptions.push(option);
            }
        });

        selectElement.innerHTML = '';
        newOptions.forEach(opt => selectElement.appendChild(opt));

        if (selectedValue) {
            selectElement.value = selectedValue;
        }
    }

    // 给单个人物条目添加「单独查询按钮」
    function addSingleQueryBtn(item) {
        const titleElement = item.querySelector('p.title');
        if (!titleElement || titleElement.querySelector('.position-single-btn')) {
            return;
        }

        // 已有职位信息则不添加按钮
        if (titleElement.querySelector('.position-tags') ||
            titleElement.querySelector('.position-indicator.error')) {
            return;
        }

        const link = titleElement.querySelector('a.l');
        const personId = getPersonId(link);
        if (!personId) {
            return;
        }

        const singleBtn = document.createElement('button');
        singleBtn.className = 'position-single-btn';
        singleBtn.textContent = '查职位';

        singleBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            if (singleBtn.classList.contains('fetching')) {
                return;
            }
            await fetchPersonPosition(personId, titleElement, singleBtn);
        });

        titleElement.appendChild(singleBtn);
    }

    // 获取所有人物职位信息（批量查询）
    async function fetchAllPositions(btn) {
        btn.classList.add('fetching');
        btn.textContent = '获取中... (点击停止)';

        const items = document.querySelectorAll('#crtRelateSubjects > li');
        let stopRequested = false;

        const stopHandler = () => {
            stopRequested = true;
            btn.textContent = '获取职位';
            btn.classList.remove('fetching');
        };
        btn.addEventListener('click', stopHandler, { once: true });

        for (const item of items) {
            if (stopRequested) break;

            const titleElement = item.querySelector('p.title');
            if (!titleElement) continue;

            // 先移除按钮（无论是否会查询，都先移除）
            removeSingleButton(titleElement);

            const link = titleElement.querySelector('a.l');
            if (!link) continue;

            const personId = getPersonId(link);
            if (!personId) continue;

            // 检查是否已有职位信息
            const existingIndicator = titleElement.querySelector('.position-tags');
            if (existingIndicator) {
                continue;
            }

            // 获取职位信息（批量查询时不传递singleBtn参数）
            await fetchPersonPosition(personId, titleElement);

            await new Promise(resolve => setTimeout(resolve, 1000));
        }

        btn.textContent = '获取职位';
        btn.classList.remove('fetching');
    }

    // 初始化脚本
    function init() {
        const editSummary = document.getElementById('editSummary');
        if (!editSummary) return;

        let container = editSummary.parentNode;
        while (container && !container.classList.contains('clearit')) {
            container = container.parentNode;
        }

        if (!container) return;

        const helperContainer = createHelperContainer();
        container.appendChild(helperContainer);

        const fetchBtn = document.getElementById('fetchPositions');
        fetchBtn.addEventListener('click', function(e) {
            e.preventDefault();
            if (!this.classList.contains('fetching')) {
                fetchAllPositions(this);
            }
        });

        // 给初始人物添加按钮
        const initialItems = document.querySelectorAll('#crtRelateSubjects > li');
        initialItems.forEach(item => addSingleQueryBtn(item));
    }


    // 等待页面加载完成
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // 监听新添加的人物
    const observer = new MutationObserver(mutations => {
        mutations.forEach(mutation => {
            if (mutation.addedNodes.length) {
                const fetchBtn = document.getElementById('fetchPositions');
                if (fetchBtn && fetchBtn.classList.contains('fetching')) {
                    // 批量查询中添加的新人物
                    const newItems = document.querySelectorAll('#crtRelateSubjects > li');
                    const lastItem = newItems[newItems.length - 1];

                    if (lastItem) {
                        const titleElement = lastItem.querySelector('p.title');
                        if (titleElement) {
                            // 先移除按钮
                            removeSingleButton(titleElement);

                            const link = titleElement.querySelector('a.l');
                            if (link) {
                                const personId = getPersonId(link);
                                if (personId) {
                                    fetchPersonPosition(personId, titleElement);
                                }
                            }
                        }
                    }
                }

                // 给新添加的人物条目加单独查询按钮
                mutation.addedNodes.forEach(node => {
                    if (node.tagName === 'LI' && node.parentElement.id === 'crtRelateSubjects') {
                        addSingleQueryBtn(node);
                    }
                });
            }
        });
    });

    // 开始观察关联人物列表的变化
    const crtRelateSubjects = document.getElementById('crtRelateSubjects');
    if (crtRelateSubjects) {
        observer.observe(crtRelateSubjects, {
            childList: true,
            subtree: false
        });
    }
})();
